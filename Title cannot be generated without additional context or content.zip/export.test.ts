import { describe, expect, it } from "vitest";
import { exportToCSV, exportToPDF } from "./export";

const mockReportData = {
  generatedAt: new Date().toISOString(),
  summary: {
    totalEvents: 17,
    totalBrands: 15,
    totalDecisionMakers: 10,
    topLeads: [
      {
        name: "João Silva",
        position: "Diretor de Marketing",
        company: "Empresa A",
        email: "joao@empresa.com",
        linkedin: "https://linkedin.com/in/joao",
        whatsapp: "+5511999999999",
      },
    ],
  },
  events: [
    {
      name: "Evento 1",
      type: "Esporte",
      segment: "Fitness",
      city: "São Paulo",
      state: "SP",
      estimatedPublic: 5000,
      mediaReach: 100000,
      conversionRate: 10,
      estimatedROI: 300,
    },
  ],
  brands: [
    {
      name: "Marca A",
      sector: "Fitness",
      positioning: "Premium",
      website: "https://marca.com",
      email: "contato@marca.com",
      phone: "+5511999999999",
    },
  ],
  decisionMakers: [
    {
      name: "Maria Santos",
      position: "Gerente de Patrocínios",
      company: "Empresa B",
      email: "maria@empresa.com",
      linkedin: "https://linkedin.com/in/maria",
      whatsapp: "+5511888888888",
      decisionLevel: "alto",
      seniority: "Senior",
      location: "São Paulo",
    },
  ],
};

describe("Export Functionality", () => {
  describe("CSV Export", () => {
    it("should export data to CSV format", async () => {
      const buffer = await exportToCSV(mockReportData);
      expect(buffer).toBeInstanceOf(Buffer);
      expect(buffer.length).toBeGreaterThan(0);
    });

    it("should include header in CSV", async () => {
      const buffer = await exportToCSV(mockReportData);
      const csv = buffer.toString("utf-8");
      expect(csv).toContain("BOP GAMES Intelligence Platform");
      expect(csv).toContain("RESUMO EXECUTIVO");
    });

    it("should include summary data in CSV", async () => {
      const buffer = await exportToCSV(mockReportData);
      const csv = buffer.toString("utf-8");
      expect(csv).toContain("Total de Eventos,17");
      expect(csv).toContain("Total de Marcas,15");
      expect(csv).toContain("Total de Decisores,10");
    });

    it("should include top leads in CSV", async () => {
      const buffer = await exportToCSV(mockReportData);
      const csv = buffer.toString("utf-8");
      expect(csv).toContain("TOP LEADS PRIORITÁRIOS");
      expect(csv).toContain("João Silva");
      expect(csv).toContain("joao@empresa.com");
    });

    it("should include events in CSV", async () => {
      const buffer = await exportToCSV(mockReportData);
      const csv = buffer.toString("utf-8");
      expect(csv).toContain("EVENTOS MAPEADOS");
      expect(csv).toContain("Evento 1");
      expect(csv).toContain("Fitness");
    });

    it("should include brands in CSV", async () => {
      const buffer = await exportToCSV(mockReportData);
      const csv = buffer.toString("utf-8");
      expect(csv).toContain("MARCAS PATROCINADORAS");
      expect(csv).toContain("Marca A");
      expect(csv).toContain("Premium");
    });

    it("should include decision makers in CSV", async () => {
      const buffer = await exportToCSV(mockReportData);
      const csv = buffer.toString("utf-8");
      expect(csv).toContain("DECISORES DE MARKETING");
      expect(csv).toContain("Maria Santos");
      expect(csv).toContain("Gerente de Patrocínios");
    });
  });

  describe("PDF Export", () => {
    it("should export data to PDF format", async () => {
      const buffer = await exportToPDF(mockReportData);
      expect(buffer).toBeInstanceOf(Buffer);
      expect(buffer.length).toBeGreaterThan(0);
    });

    it("should generate valid PDF binary", async () => {
      const buffer = await exportToPDF(mockReportData);
      // PDF files start with %PDF
      const hex = buffer.toString("hex").substring(0, 8);
      expect(hex).toMatch(/^25504446/); // %PDF in hex
    });

    it("should include summary metrics in PDF", async () => {
      const buffer = await exportToPDF(mockReportData);
      // PDF should contain summary data
      const pdf = buffer.toString("utf-8");
      expect(pdf).toContain("%PDF");
      expect(pdf).toContain("RESUMO EXECUTIVO");
    });
  });

  describe("Data Integrity", () => {
    it("should preserve all top leads in export", async () => {
      const buffer = await exportToCSV(mockReportData);
      const csv = buffer.toString("utf-8");
      mockReportData.summary.topLeads.forEach(lead => {
        expect(csv).toContain(lead.name);
        expect(csv).toContain(lead.email);
      });
    });

    it("should preserve all events in export", async () => {
      const buffer = await exportToCSV(mockReportData);
      const csv = buffer.toString("utf-8");
      mockReportData.events.forEach(event => {
        expect(csv).toContain(event.name);
        expect(csv).toContain(event.segment);
      });
    });

    it("should preserve all brands in export", async () => {
      const buffer = await exportToCSV(mockReportData);
      const csv = buffer.toString("utf-8");
      mockReportData.brands.forEach(brand => {
        expect(csv).toContain(brand.name);
        expect(csv).toContain(brand.sector);
      });
    });
  });
});
