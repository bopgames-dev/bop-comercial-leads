import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, float } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Eventos esportivos brasileiros
 */
export const events = mysqlTable("events", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  type: varchar("type", { length: 100 }).notNull(), // Tênis, Crossfit, Corrida, etc
  segment: varchar("segment", { length: 100 }).notNull(), // Fitness, Esporte, Lifestyle
  description: text("description"),
  city: varchar("city", { length: 100 }).notNull(),
  state: varchar("state", { length: 2 }),
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  estimatedPublic: int("estimatedPublic"), // Público estimado
  mediaReach: int("mediaReach"), // Alcance de mídia
  conversionRate: float("conversionRate"), // Taxa de conversão em %
  estimatedROI: float("estimatedROI"), // ROI estimado em %
  website: varchar("website", { length: 255 }),
  email: varchar("email", { length: 255 }),
  phone: varchar("phone", { length: 20 }),
  sponsorCount: int("sponsorCount").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Event = typeof events.$inferSelect;
export type InsertEvent = typeof events.$inferInsert;

/**
 * Marcas patrocinadoras
 */
export const brands = mysqlTable("brands", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  sector: varchar("sector", { length: 100 }).notNull(), // Suplementação, Fitness, Telecomunicações, etc
  positioning: varchar("positioning", { length: 100 }), // Premium, Popular, Nichado
  website: varchar("website", { length: 255 }),
  email: varchar("email", { length: 255 }),
  phone: varchar("phone", { length: 20 }),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Brand = typeof brands.$inferSelect;
export type InsertBrand = typeof brands.$inferInsert;

/**
 * Patrocínios (relação entre marcas e eventos)
 */
export const sponsorships = mysqlTable("sponsorships", {
  id: int("id").autoincrement().primaryKey(),
  brandId: int("brandId").notNull(),
  eventId: int("eventId").notNull(),
  sponsorshipType: mysqlEnum("sponsorshipType", ["master", "apresentador", "ouro", "prata", "bronze", "apoio"]).notNull(),
  activationStrategy: text("activationStrategy"),
  startDate: timestamp("startDate"),
  endDate: timestamp("endDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Sponsorship = typeof sponsorships.$inferSelect;
export type InsertSponsorship = typeof sponsorships.$inferInsert;

/**
 * Decisores e executivos de marketing
 */
export const decisionMakers = mysqlTable("decisionMakers", {
  id: int("id").autoincrement().primaryKey(),
  fullName: varchar("fullName", { length: 255 }).notNull(),
  position: varchar("position", { length: 150 }).notNull(), // CMO, Head de Marketing, etc
  company: varchar("company", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 20 }),
  linkedinUrl: varchar("linkedinUrl", { length: 255 }),
  whatsapp: varchar("whatsapp", { length: 20 }),
  decisionLevel: mysqlEnum("decisionLevel", ["alto", "medio", "influenciador"]).default("medio"),
  seniority: varchar("seniority", { length: 50 }), // Junior, Pleno, Senior, Executive
  location: varchar("location", { length: 100 }),
  sponsorshipHistory: text("sponsorshipHistory"), // JSON com histórico
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DecisionMaker = typeof decisionMakers.$inferSelect;
export type InsertDecisionMaker = typeof decisionMakers.$inferInsert;

/**
 * Relatórios estratégicos
 */
export const reports = mysqlTable("reports", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content").notNull(), // JSON com análise completa
  insights: text("insights"), // JSON com insights principais
  topLeads: text("topLeads"), // JSON com leads prioritários
  generatedBy: int("generatedBy"), // user_id
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Report = typeof reports.$inferSelect;
export type InsertReport = typeof reports.$inferInsert;
