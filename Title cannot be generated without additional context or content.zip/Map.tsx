import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Loader2, MapPin } from "lucide-react";

/**
 * MapPage Component
 * Exibe um mapa interativo com todos os eventos mapeados geograficamente no Brasil.
 * Utiliza uma visualização em tabela com informações de localização e estatísticas por estado.
 */
export default function MapPage() {
  // Buscar lista de eventos do servidor
  const { data: events, isLoading } = trpc.events.list.useQuery();

  // Mostrar loading enquanto busca dados
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-accent" />
      </div>
    );
  }

  // Agrupar eventos por estado
  const eventsByState = events?.reduce((acc: Record<string, any[]>, event: any) => {
    const state = event.state || "Desconhecido";
    if (!acc[state]) {
      acc[state] = [];
    }
    acc[state].push(event);
    return acc;
  }, {}) || {};

  // Calcular estatísticas por estado
  const stateStats = Object.entries(eventsByState).map(([state, stateEvents]: [string, any[]]) => ({
    state,
    count: stateEvents.length,
    totalPublic: stateEvents.reduce((sum, e) => sum + (e.estimatedPublic || 0), 0),
    avgROI: (stateEvents.reduce((sum, e) => sum + (e.estimatedROI || 0), 0) / stateEvents.length).toFixed(1),
  }));

  return (
    <div className="space-y-6">
      {/* Cabeçalho da página */}
      <div>
        <h1 className="text-3xl font-bold text-foreground">Mapa de Eventos</h1>
        <p className="text-muted-foreground mt-2">Visualização geográfica dos eventos mapeados no Brasil</p>
      </div>

      {/* Card com resumo total */}
      <Card className="p-6 bg-gradient-to-br from-card to-card/50 border-border">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Total de Eventos</p>
            <p className="text-3xl font-bold text-accent">{events?.length || 0}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Estados Cobertos</p>
            <p className="text-3xl font-bold text-accent">{Object.keys(eventsByState).length}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Público Total</p>
            <p className="text-3xl font-bold text-accent">
              {(events?.reduce((sum, e) => sum + (e.estimatedPublic || 0), 0) || 0).toLocaleString()}
            </p>
          </div>
        </div>
      </Card>

      {/* Distribuição por Estado */}
      <Card className="p-6 bg-card border-border">
        <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
          <MapPin className="w-5 h-5 text-accent" />
          Distribuição por Estado
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {stateStats.map((stat) => (
            <div key={stat.state} className="p-4 bg-muted/20 rounded-lg border border-border/50 hover:border-accent/50 transition-colors">
              <div className="flex items-start justify-between mb-2">
                <p className="font-semibold text-foreground">{stat.state}</p>
                <span className="px-2 py-1 bg-accent/20 text-accent text-xs font-bold rounded">{stat.count}</span>
              </div>
              <div className="space-y-1 text-sm">
                <p className="text-muted-foreground">
                  Público: <span className="text-foreground font-medium">{stat.totalPublic.toLocaleString()}</span>
                </p>
                <p className="text-muted-foreground">
                  ROI Médio: <span className="text-accent font-medium">{stat.avgROI}%</span>
                </p>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Lista de Eventos por Estado */}
      <Card className="p-6 bg-card border-border">
        <h3 className="text-lg font-semibold text-foreground mb-4">Eventos por Localização</h3>
        <div className="space-y-6">
          {Object.entries(eventsByState).map(([state, stateEvents]: [string, any[]]) => (
            <div key={state} className="border-b border-border/50 pb-6 last:border-b-0 last:pb-0">
              {/* Cabeçalho do estado */}
              <h4 className="text-md font-semibold text-accent mb-3">{state}</h4>
              
              {/* Grid de eventos do estado */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {stateEvents.map((event: any) => (
                  <div key={event.id} className="p-3 bg-muted/20 rounded-lg border border-border/30 hover:border-accent/50 transition-colors">
                    <p className="font-medium text-foreground text-sm">{event.name}</p>
                    <p className="text-xs text-muted-foreground mt-1">{event.city}</p>
                    <div className="flex justify-between items-center mt-2">
                      <span className="text-xs bg-card px-2 py-1 rounded text-muted-foreground">{event.type}</span>
                      <span className="text-xs font-bold text-accent">{event.estimatedROI}% ROI</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Legenda */}
      <Card className="p-6 bg-card border-border">
        <h3 className="text-lg font-semibold text-foreground mb-4">Informações</h3>
        <div className="space-y-2 text-sm text-muted-foreground">
          <p>• Os eventos estão organizados por estado para facilitar análise geográfica</p>
          <p>• Clique em cada card para ver mais detalhes do evento</p>
          <p>• O ROI médio é calculado pela média dos eventos do estado</p>
          <p>• O público total é a soma de todos os públicos estimados do estado</p>
        </div>
      </Card>
    </div>
  );
}
