#!/usr/bin/env python3
"""
Generate Drizzle ORM schema from entity definition.

Usage:
    python generate_schema.py --entities events,brands,contacts --output schema.ts

This script generates a complete Drizzle ORM schema file based on entity definitions.
"""

import json
import argparse
from typing import List, Dict, Any

# Entity templates
ENTITY_TEMPLATES = {
    "events": {
        "fields": [
            ("id", "int", "PRIMARY KEY AUTO_INCREMENT"),
            ("name", "varchar(255)", "NOT NULL"),
            ("type", "varchar(100)", ""),
            ("segment", "varchar(100)", ""),
            ("city", "varchar(100)", ""),
            ("state", "varchar(2)", ""),
            ("latitude", "decimal(10,8)", ""),
            ("longitude", "decimal(11,8)", ""),
            ("estimatedPublic", "int", ""),
            ("mediaReach", "int", ""),
            ("conversionRate", "decimal(5,2)", ""),
            ("estimatedROI", "decimal(5,2)", ""),
            ("createdAt", "timestamp", "DEFAULT CURRENT_TIMESTAMP"),
        ]
    },
    "brands": {
        "fields": [
            ("id", "int", "PRIMARY KEY AUTO_INCREMENT"),
            ("name", "varchar(255)", "NOT NULL"),
            ("sector", "varchar(100)", ""),
            ("website", "varchar(255)", ""),
            ("email", "varchar(320)", ""),
            ("phone", "varchar(20)", ""),
            ("sponsorshipLevel", "varchar(50)", ""),
            ("createdAt", "timestamp", "DEFAULT CURRENT_TIMESTAMP"),
        ]
    },
    "contacts": {
        "fields": [
            ("id", "int", "PRIMARY KEY AUTO_INCREMENT"),
            ("name", "varchar(255)", "NOT NULL"),
            ("position", "varchar(255)", ""),
            ("email", "varchar(320)", ""),
            ("phone", "varchar(20)", ""),
            ("linkedin", "varchar(255)", ""),
            ("decisionLevel", "varchar(50)", ""),
            ("brandId", "int", ""),
            ("createdAt", "timestamp", "DEFAULT CURRENT_TIMESTAMP"),
        ]
    },
}

def generate_drizzle_schema(entities: List[str]) -> str:
    """Generate Drizzle ORM schema TypeScript code."""
    
    schema = """import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal } from "drizzle-orm/mysql-core";

/**
 * Database Schema - Commercial Intelligence Platform
 * 
 * This file defines all database tables using Drizzle ORM.
 * Tables are generated based on entity definitions.
 * 
 * To apply changes:
 * 1. Run: pnpm drizzle-kit generate
 * 2. Review generated SQL migration
 * 3. Run: pnpm db:push
 */

// Users table - Authentication
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

"""
    
    # Generate entity tables
    for entity in entities:
        if entity in ENTITY_TEMPLATES:
            template = ENTITY_TEMPLATES[entity]
            table_name = entity.lower()
            
            schema += f"""// {entity.capitalize()} table
export const {entity} = mysqlTable("{table_name}", {{
"""
            
            for field_name, field_type, constraints in template["fields"]:
                # Map SQL types to Drizzle types
                if "int" in field_type and "PRIMARY KEY" in constraints:
                    drizzle_type = f'int("{field_name}").autoincrement().primaryKey()'
                elif "int" in field_type:
                    drizzle_type = f'int("{field_name}")'
                elif "decimal" in field_type:
                    drizzle_type = f'decimal("{field_name}", {{ precision: 10, scale: 2 }})'
                elif "timestamp" in field_type:
                    if "DEFAULT CURRENT_TIMESTAMP" in constraints:
                        drizzle_type = f'timestamp("{field_name}").defaultNow()'
                    else:
                        drizzle_type = f'timestamp("{field_name}")'
                elif "varchar" in field_type:
                    length = field_type.split("(")[1].split(")")[0]
                    drizzle_type = f'varchar("{field_name}", {{ length: {length} }})'
                else:
                    drizzle_type = f'text("{field_name}")'
                
                # Add constraints
                if "NOT NULL" in constraints:
                    drizzle_type += ".notNull()"
                
                schema += f"  {field_name}: {drizzle_type},\n"
            
            schema += f"}});\n\n"
            schema += f"export type {entity.capitalize()} = typeof {entity}.$inferSelect;\n"
            schema += f"export type Insert{entity.capitalize()} = typeof {entity}.$inferInsert;\n\n"
    
    return schema

def main():
    parser = argparse.ArgumentParser(description="Generate Drizzle ORM schema")
    parser.add_argument("--entities", type=str, default="events,brands,contacts",
                       help="Comma-separated list of entities to generate")
    parser.add_argument("--output", type=str, default="schema.ts",
                       help="Output file path")
    
    args = parser.parse_args()
    entities = [e.strip() for e in args.entities.split(",")]
    
    schema = generate_drizzle_schema(entities)
    
    with open(args.output, "w") as f:
        f.write(schema)
    
    print(f"✅ Schema generated: {args.output}")
    print(f"   Entities: {', '.join(entities)}")
    print(f"\nNext steps:")
    print(f"  1. pnpm drizzle-kit generate")
    print(f"  2. pnpm db:push")

if __name__ == "__main__":
    main()
