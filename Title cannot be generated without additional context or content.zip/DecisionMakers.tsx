import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState, useMemo } from "react";
import { Loader2, Mail, Linkedin, MessageCircle, Briefcase, MapPin } from "lucide-react";

const DECISION_LEVEL_COLORS: Record<string, string> = {
  alto: "bg-red-500/10 text-red-600 border-red-500/20",
  medio: "bg-orange-500/10 text-orange-600 border-orange-500/20",
  influenciador: "bg-blue-500/10 text-blue-600 border-blue-500/20",
};

export default function DecisionMakers() {
  const { data: decisionMakers, isLoading } = trpc.decisionMakers.list.useQuery();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCompany, setSelectedCompany] = useState<string | null>(null);
  const [selectedLevel, setSelectedLevel] = useState<string | null>(null);

  const companies = useMemo(
    () => Array.from(new Set(decisionMakers?.map(dm => dm.company) || [])),
    [decisionMakers]
  );

  const filteredDecisionMakers = useMemo(() => {
    if (!decisionMakers) return [];
    return decisionMakers.filter(dm => {
      const matchesSearch =
        dm.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        dm.position.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCompany = !selectedCompany || dm.company === selectedCompany;
      const matchesLevel = !selectedLevel || dm.decisionLevel === selectedLevel;
      return matchesSearch && matchesCompany && matchesLevel;
    });
  }, [decisionMakers, searchTerm, selectedCompany, selectedLevel]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-accent" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Decisores de Marketing</h1>
        <p className="text-muted-foreground mt-2">Contatos executivos para estratégia de leads</p>
      </div>

      {/* Filtros */}
      <Card className="p-6 bg-card border-border">
        <h3 className="text-lg font-semibold text-foreground mb-4">Filtros</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="text-sm text-muted-foreground block mb-2">Buscar</label>
            <Input
              placeholder="Nome ou cargo..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-input border-border"
            />
          </div>
          <div>
            <label className="text-sm text-muted-foreground block mb-2">Empresa</label>
            <select
              value={selectedCompany || ""}
              onChange={(e) => setSelectedCompany(e.target.value || null)}
              className="w-full px-3 py-2 bg-input border border-border rounded-lg text-foreground"
            >
              <option value="">Todas</option>
              {companies.map((company: string) => (
                <option key={company} value={company}>{company}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-sm text-muted-foreground block mb-2">Nível de Decisão</label>
            <select
              value={selectedLevel || ""}
              onChange={(e) => setSelectedLevel(e.target.value || null)}
              className="w-full px-3 py-2 bg-input border border-border rounded-lg text-foreground"
            >
              <option value="">Todos</option>
              <option value="alto">Alto</option>
              <option value="medio">Médio</option>
              <option value="influenciador">Influenciador</option>
            </select>
          </div>
          <div className="flex items-end">
            <Button
              onClick={() => {
                setSearchTerm("");
                setSelectedCompany(null);
                setSelectedLevel(null);
              }}
              variant="outline"
              className="w-full"
            >
              Limpar
            </Button>
          </div>
        </div>
      </Card>

      {/* Lista de Decisores */}
      <div className="space-y-4">
        {filteredDecisionMakers.map(dm => (
          <Card key={dm.id} className="p-6 bg-card border-border hover:border-accent transition-colors">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold text-foreground">{dm.fullName}</h3>
                <p className="text-sm text-accent mt-1">{dm.position}</p>
              </div>
              <div className={`px-3 py-1 rounded-full text-xs font-medium border ${DECISION_LEVEL_COLORS[dm.decisionLevel || "medio"]}`}>
                {dm.decisionLevel === "alto" && "Alto"}
                {dm.decisionLevel === "medio" && "Médio"}
                {dm.decisionLevel === "influenciador" && "Influenciador"}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="flex items-center gap-2 text-sm">
                <Briefcase className="w-4 h-4 text-accent" />
                <span className="text-foreground">{dm.company}</span>
              </div>
              {dm.location && (
                <div className="flex items-center gap-2 text-sm">
                  <MapPin className="w-4 h-4 text-accent" />
                  <span className="text-foreground">{dm.location}</span>
                </div>
              )}
            </div>

            {dm.seniority && (
              <div className="mb-4 p-2 bg-muted/20 rounded">
                <p className="text-xs text-muted-foreground">Senioridade</p>
                <p className="text-sm font-medium text-foreground">{dm.seniority}</p>
              </div>
            )}

            {/* Botões de Ação */}
            <div className="flex flex-wrap gap-2">
              {dm.email && (
                <Button
                  onClick={() => window.location.href = `mailto:${dm.email || ""}`}
                  size="sm"
                  className="gap-2 bg-accent hover:bg-accent/90"
                >
                  <Mail className="w-4 h-4" />
                  Email
                </Button>
              )}
              {dm.linkedinUrl && (
                <Button
                  onClick={() => window.open(dm.linkedinUrl || "", "_blank")}
                  size="sm"
                  variant="outline"
                  className="gap-2"
                >
                  <Linkedin className="w-4 h-4" />
                  LinkedIn
                </Button>
              )}
              {dm.whatsapp && (
                <Button
                  onClick={() => {
                    const phoneNumber = dm.whatsapp?.replace(/\D/g, "") || "";
                    window.open(`https://wa.me/${phoneNumber}`, "_blank");
                  }}
                  size="sm"
                  variant="outline"
                  className="gap-2"
                >
                  <MessageCircle className="w-4 h-4" />
                  WhatsApp
                </Button>
              )}
            </div>
          </Card>
        ))}
      </div>

      {filteredDecisionMakers.length === 0 && (
        <Card className="p-12 bg-card border-border text-center">
          <p className="text-muted-foreground">Nenhum decisor encontrado com os filtros selecionados</p>
        </Card>
      )}
    </div>
  );
}
