CREATE TABLE `brands` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`sector` varchar(100) NOT NULL,
	`positioning` varchar(100),
	`website` varchar(255),
	`email` varchar(255),
	`phone` varchar(20),
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `brands_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `decisionMakers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`fullName` varchar(255) NOT NULL,
	`position` varchar(150) NOT NULL,
	`company` varchar(255) NOT NULL,
	`email` varchar(255) NOT NULL,
	`phone` varchar(20),
	`linkedinUrl` varchar(255),
	`whatsapp` varchar(20),
	`decisionLevel` enum('alto','medio','influenciador') DEFAULT 'medio',
	`seniority` varchar(50),
	`location` varchar(100),
	`sponsorshipHistory` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `decisionMakers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`type` varchar(100) NOT NULL,
	`segment` varchar(100) NOT NULL,
	`description` text,
	`city` varchar(100) NOT NULL,
	`state` varchar(2),
	`latitude` decimal(10,8),
	`longitude` decimal(11,8),
	`estimatedPublic` int,
	`mediaReach` int,
	`conversionRate` float,
	`estimatedROI` float,
	`website` varchar(255),
	`email` varchar(255),
	`phone` varchar(20),
	`sponsorCount` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`content` text NOT NULL,
	`insights` text,
	`topLeads` text,
	`generatedBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `reports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sponsorships` (
	`id` int AUTO_INCREMENT NOT NULL,
	`brandId` int NOT NULL,
	`eventId` int NOT NULL,
	`sponsorshipType` enum('master','apresentador','ouro','prata','bronze','apoio') NOT NULL,
	`activationStrategy` text,
	`startDate` timestamp,
	`endDate` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `sponsorships_id` PRIMARY KEY(`id`)
);
