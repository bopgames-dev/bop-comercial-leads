# BOP GAMES Intelligence Platform - Documentação Completa

## 📋 Índice
1. [Visão Geral](#visão-geral)
2. [Requisitos do Sistema](#requisitos-do-sistema)
3. [Instalação](#instalação)
4. [Configuração](#configuração)
5. [Estrutura do Projeto](#estrutura-do-projeto)
6. [Funcionalidades](#funcionalidades)
7. [Guia de Uso](#guia-de-uso)
8. [Deployment](#deployment)
9. [Troubleshooting](#troubleshooting)

---

## Visão Geral

A **BOP GAMES Intelligence Platform** é uma plataforma web completa de inteligência comercial para mapeamento de patrocínios em eventos esportivos brasileiros. Desenvolvida com React, TypeScript, Express e tRPC, oferece um dashboard executivo com análise de dados, gestão de leads e exportação de relatórios.

### Características Principais
- Dashboard com 4 KPIs principais e 4 gráficos interativos
- Banco de dados com 17 eventos esportivos brasileiros
- Catálogo de 15 marcas patrocinadoras
- Perfis de 10 decisores de marketing
- Mapa interativo com distribuição geográfica
- Relatório estratégico com análise de oportunidades
- Exportação de dados em JSON, CSV e PDF
- Tema dark com acentos laranja/vermelho
- Autenticação OAuth integrada

---

## Requisitos do Sistema

### Ambiente de Desenvolvimento
- **Node.js**: v22.13.0 ou superior
- **pnpm**: v10.15.1 ou superior
- **Git**: v2.34.0 ou superior
- **MySQL/TiDB**: Para banco de dados

### Ambiente de Produção
- **Node.js**: v22.13.0 ou superior
- **MySQL/TiDB**: Banco de dados remoto
- **Domínio próprio**: Para hospedagem
- **SSL/TLS**: Certificado HTTPS

---

## Instalação

### 1. Clonar o Repositório
```bash
git clone <seu-repositorio>
cd bop-intelligence-platform
```

### 2. Instalar Dependências
```bash
pnpm install
```

### 3. Configurar Variáveis de Ambiente
Crie um arquivo `.env.local` na raiz do projeto:

```env
# Banco de Dados
DATABASE_URL=mysql://usuario:senha@localhost:3306/bop_games

# Autenticação OAuth
VITE_APP_ID=seu_app_id
OAUTH_SERVER_URL=https://api.oauth.com
VITE_OAUTH_PORTAL_URL=https://oauth.com/login

# JWT
JWT_SECRET=sua_chave_secreta_jwt

# Informações do Proprietário
OWNER_OPEN_ID=seu_open_id
OWNER_NAME=BOP GAMES

# APIs Internas
BUILT_IN_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=sua_chave_api
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im
VITE_FRONTEND_FORGE_API_KEY=sua_chave_frontend
```

### 4. Executar Migrações do Banco de Dados
```bash
pnpm db:push
```

### 5. Iniciar o Servidor de Desenvolvimento
```bash
pnpm dev
```

A aplicação estará disponível em `http://localhost:3000`

---

## Configuração

### Banco de Dados

#### Schema Principal
O projeto utiliza Drizzle ORM com as seguintes tabelas:

**Tabela: users**
- Armazena informações de usuários autenticados
- Campos: id, openId, name, email, loginMethod, role, createdAt, updatedAt, lastSignedIn

**Tabela: events**
- Eventos esportivos mapeados
- Campos: id, name, type, segment, city, state, latitude, longitude, estimatedPublic, mediaReach, conversionRate, estimatedROI, createdAt

**Tabela: brands**
- Marcas patrocinadoras
- Campos: id, name, sector, website, email, phone, sponsorshipLevel, createdAt

**Tabela: sponsorships**
- Relação entre marcas e eventos
- Campos: id, brandId, eventId, sponsorshipType, startDate, endDate, createdAt

**Tabela: decisionMakers**
- Decisores de marketing
- Campos: id, name, position, email, linkedin, phone, decisionLevel, brandId, createdAt

**Tabela: reports**
- Relatórios estratégicos gerados
- Campos: id, title, content, generatedAt, userId, createdAt

---

## Estrutura do Projeto

```
bop-intelligence-platform/
├── client/                          # Frontend React
│   ├── src/
│   │   ├── pages/                   # Páginas da aplicação
│   │   │   ├── Dashboard.tsx        # Dashboard principal com KPIs
│   │   │   ├── Events.tsx           # Lista de eventos com filtros
│   │   │   ├── Brands.tsx           # Catálogo de marcas
│   │   │   ├── DecisionMakers.tsx   # Contatos executivos
│   │   │   ├── Map.tsx              # Mapa interativo
│   │   │   └── Report.tsx           # Relatório estratégico
│   │   ├── components/              # Componentes reutilizáveis
│   │   │   ├── BOPDashboardLayout.tsx  # Layout com sidebar
│   │   │   └── ui/                  # Componentes shadcn/ui
│   │   ├── lib/
│   │   │   └── trpc.ts              # Cliente tRPC
│   │   ├── App.tsx                  # Roteamento principal
│   │   ├── main.tsx                 # Entry point
│   │   └── index.css                # Estilos globais (tema dark)
│   └── public/                      # Arquivos estáticos
│
├── server/                          # Backend Express
│   ├── db.ts                        # Helpers de banco de dados
│   ├── routers.ts                   # Procedimentos tRPC
│   ├── features.test.ts             # Testes unitários
│   └── _core/                       # Framework interno
│       ├── index.ts                 # Servidor Express
│       ├── context.ts               # Contexto tRPC
│       ├── trpc.ts                  # Configuração tRPC
│       ├── auth.ts                  # Autenticação OAuth
│       └── env.ts                   # Variáveis de ambiente
│
├── drizzle/                         # Migrações do banco
│   ├── schema.ts                    # Definição de tabelas
│   └── *.sql                        # Arquivos de migração
│
├── shared/                          # Código compartilhado
│   └── const.ts                     # Constantes globais
│
├── storage/                         # Helpers de armazenamento S3
│   └── index.ts                     # Funções de upload/download
│
├── package.json                     # Dependências do projeto
├── tsconfig.json                    # Configuração TypeScript
├── vite.config.ts                   # Configuração Vite
└── drizzle.config.ts                # Configuração Drizzle ORM
```

---

## Funcionalidades

### 1. Dashboard
**Localização**: `/`

Exibe 4 KPIs principais:
- Total de Eventos Mapeados (17)
- Total de Marcas Patrocinadoras (15)
- Total de Decisores Mapeados (10)
- ROI Médio Estimado (377.1%)

Inclui 4 gráficos interativos:
- Eventos por Segmento (Esporte, Fitness, Lifestyle)
- Marcas por Setor (Tecnologia, Fitness, Energia, Banco, Naturais)
- Distribuição por Tipo de Patrocínio (Master, Ouro, Prata, Bronze, Apoio)
- Top 5 Eventos por ROI

### 2. Eventos
**Localização**: `/events`

- Lista completa de 17 eventos com cards informativos
- Filtros por segmento (Esporte, Fitness, Lifestyle)
- Filtros por cidade (Rio de Janeiro, São Paulo, Brasília, Várias cidades)
- Busca por nome do evento
- Botões de ação: Site e Email
- Informações: tipo, segmento, localização, público, alcance, taxa de conversão, ROI

### 3. Marcas
**Localização**: `/brands`

- Catálogo de 15 marcas patrocinadoras
- Filtros por setor (Tecnologia, Fitness, Energia, Banco, Naturais)
- Informações: nome, setor, website, email, telefone, nível de patrocínio
- Botões de ação: Site e Email

### 4. Decisores
**Localização**: `/decision-makers`

- Lista de 10 decisores de marketing
- Informações: nome, cargo, email, LinkedIn, telefone, nível de decisão
- Botões de ação: Email, LinkedIn, WhatsApp
- Filtros por nível de decisão (Alto, Médio, Baixo)

### 5. Mapa
**Localização**: `/map`

- Visualização geográfica dos eventos por estado
- Distribuição por estado com estatísticas
- Informações de público total e ROI médio por estado
- Lista de eventos agrupados por localização

### 6. Relatório
**Localização**: `/report`

- Análise estratégica com resumo executivo
- Top 10 leads prioritários
- Oportunidades por segmento
- Exportação em JSON (estrutura completa)
- Recomendações estratégicas

---

## Guia de Uso

### Navegação Principal
A navegação lateral (sidebar) permite acesso rápido a todas as seções:
- **Dashboard**: Visão geral com KPIs
- **Eventos**: Mapeamento de eventos
- **Marcas**: Catálogo de patrocinadoras
- **Decisores**: Contatos executivos
- **Mapa**: Distribuição geográfica
- **Relatório**: Análise estratégica

### Filtros e Busca
- Use os campos de busca para encontrar eventos ou marcas específicas
- Aplique filtros para segmentar dados por tipo, segmento ou localização
- Clique em "Limpar Filtros" para resetar todas as seleções

### Exportação de Dados
No Dashboard ou em páginas específicas:
- Clique no botão "Exportar" para baixar dados em JSON
- Selecione o formato desejado (JSON, CSV, PDF) antes de exportar

### Links de Ação
- **Email**: Abre cliente de email padrão
- **LinkedIn**: Abre perfil no LinkedIn
- **WhatsApp**: Inicia conversa no WhatsApp Web
- **Site**: Abre website da empresa

---

## Deployment

### Opção 1: Hospedagem em Manus (Recomendado)
1. Clique no botão "Publish" na interface de gerenciamento
2. Selecione o domínio desejado (manus.space ou domínio customizado)
3. Aguarde a publicação (2-5 minutos)

### Opção 2: Hospedagem em Domínio Próprio

#### Pré-requisitos
- Servidor com Node.js v22+
- Banco de dados MySQL/TiDB remoto
- Domínio próprio com DNS configurado
- SSL/TLS ativo

#### Passos

1. **Preparar Servidor**
```bash
# Instalar Node.js
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt-get install -y nodejs

# Instalar pnpm
npm install -g pnpm
```

2. **Clonar e Configurar**
```bash
git clone <seu-repositorio>
cd bop-intelligence-platform
pnpm install
```

3. **Configurar Variáveis de Ambiente**
```bash
cp .env.example .env.production
# Editar .env.production com valores reais
```

4. **Build para Produção**
```bash
pnpm build
```

5. **Iniciar Servidor**
```bash
NODE_ENV=production pnpm start
```

6. **Configurar Reverse Proxy (Nginx)**
```nginx
server {
    listen 443 ssl http2;
    server_name seu-dominio.com;

    ssl_certificate /etc/letsencrypt/live/seu-dominio.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/seu-dominio.com/privkey.pem;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

7. **Reiniciar Nginx**
```bash
sudo systemctl restart nginx
```

---

## Troubleshooting

### Erro: "Database connection failed"
**Solução**: Verifique a variável `DATABASE_URL` e certifique-se de que o banco de dados está acessível.

### Erro: "OAuth callback failed"
**Solução**: Valide as variáveis `VITE_APP_ID` e `OAUTH_SERVER_URL`. Certifique-se de que o domínio está registrado na aplicação OAuth.

### Página em branco ao carregar
**Solução**: Limpe o cache do navegador (Ctrl+Shift+Delete) e recarregue a página.

### Filtros não funcionam
**Solução**: Verifique o console do navegador (F12) para erros. Certifique-se de que os dados foram carregados corretamente.

### Exportação de relatório não funciona
**Solução**: Verifique se o navegador permite downloads. Desabilite bloqueadores de pop-ups.

---

## Suporte e Contribuição

Para dúvidas ou problemas, entre em contato através de:
- Email: contato@bopgames.com.br
- Website: https://bopgames.com.br

---

## Licença

Todos os direitos reservados © 2026 BOP GAMES. Uso exclusivo para fins comerciais autorizados.

---

**Versão**: 1.0.0  
**Data de Atualização**: 04 de maio de 2026  
**Desenvolvido com**: React 19, TypeScript, Express 4, tRPC 11
