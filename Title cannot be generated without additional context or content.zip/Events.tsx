import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState, useMemo } from "react";
import { Loader2, MapPin, Users, TrendingUp } from "lucide-react";

export default function Events() {
  const { data: events, isLoading } = trpc.events.list.useQuery();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedSegment, setSelectedSegment] = useState<string | null>(null);
  const [selectedCity, setSelectedCity] = useState<string | null>(null);

  const segments = useMemo(
    () => Array.from(new Set(events?.map(e => e.segment) || [])),
    [events]
  );

  const cities = useMemo(
    () => Array.from(new Set(events?.map(e => e.city) || [])),
    [events]
  );

  const filteredEvents = useMemo(() => {
    if (!events) return [];
    return events.filter(event => {
      const matchesSearch = event.name.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesSegment = !selectedSegment || event.segment === selectedSegment;
      const matchesCity = !selectedCity || event.city === selectedCity;
      return matchesSearch && matchesSegment && matchesCity;
    });
  }, [events, searchTerm, selectedSegment, selectedCity]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-accent" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Eventos Esportivos</h1>
        <p className="text-muted-foreground mt-2">Mapeamento completo de eventos no Brasil</p>
      </div>

      {/* Filtros */}
      <Card className="p-6 bg-card border-border">
        <h3 className="text-lg font-semibold text-foreground mb-4">Filtros</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="text-sm text-muted-foreground block mb-2">Buscar evento</label>
            <Input
              placeholder="Nome do evento..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-input border-border"
            />
          </div>
          <div>
            <label className="text-sm text-muted-foreground block mb-2">Segmento</label>
            <select
              value={selectedSegment || ""}
              onChange={(e) => setSelectedSegment(e.target.value || null)}
              className="w-full px-3 py-2 bg-input border border-border rounded-lg text-foreground"
            >
              <option value="">Todos</option>
              {segments.map((segment: string) => (
                <option key={segment} value={segment}>{segment}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-sm text-muted-foreground block mb-2">Cidade</label>
            <select
              value={selectedCity || ""}
              onChange={(e) => setSelectedCity(e.target.value || null)}
              className="w-full px-3 py-2 bg-input border border-border rounded-lg text-foreground"
            >
              <option value="">Todas</option>
              {cities.map((city: string) => (
                <option key={city} value={city}>{city}</option>
              ))}
            </select>
          </div>
          <div className="flex items-end">
            <Button
              onClick={() => {
                setSearchTerm("");
                setSelectedSegment(null);
                setSelectedCity(null);
              }}
              variant="outline"
              className="w-full"
            >
              Limpar Filtros
            </Button>
          </div>
        </div>
      </Card>

      {/* Lista de Eventos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {filteredEvents.map(event => (
          <Card key={event.id} className="p-6 bg-card border-border hover:border-accent transition-colors">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold text-foreground">{event.name}</h3>
                <p className="text-sm text-accent mt-1">{event.type}</p>
              </div>
              <span className="px-3 py-1 bg-accent/10 text-accent rounded-full text-xs font-medium">
                {event.segment}
              </span>
            </div>

            <p className="text-sm text-muted-foreground mb-4">{event.description}</p>

            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-accent" />
                <span className="text-sm text-foreground">{event.city}, {event.state}</span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-accent" />
                <span className="text-sm text-foreground">{event.estimatedPublic?.toLocaleString()} público</span>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2 p-3 bg-muted/20 rounded-lg mb-4">
              <div>
                <p className="text-xs text-muted-foreground">Alcance</p>
                <p className="text-sm font-semibold text-foreground">{(event.mediaReach || 0) / 1000000}M</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Conversão</p>
                <p className="text-sm font-semibold text-accent">{event.conversionRate?.toFixed(1)}%</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">ROI</p>
                <p className="text-sm font-semibold text-accent">{event.estimatedROI}%</p>
              </div>
            </div>

            <div className="flex gap-2">
              {event.website && (
                <Button
                  onClick={() => window.open(event.website || "", "_blank")}
                  size="sm"
                  variant="outline"
                  className="flex-1"
                >
                  Site
                </Button>
              )}
              {event.email && (
                <Button
                  onClick={() => window.location.href = `mailto:${event.email || ""}`}
                  size="sm"
                  variant="outline"
                  className="flex-1"
                >
                  Email
                </Button>
              )}
            </div>
          </Card>
        ))}
      </div>

      {filteredEvents.length === 0 && (
        <Card className="p-12 bg-card border-border text-center">
          <p className="text-muted-foreground">Nenhum evento encontrado com os filtros selecionados</p>
        </Card>
      )}
    </div>
  );
}
