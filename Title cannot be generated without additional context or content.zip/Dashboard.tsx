import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Loader2 } from "lucide-react";

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = trpc.events.stats.useQuery();
  const { data: events, isLoading: eventsLoading } = trpc.events.list.useQuery();
  const { data: brands, isLoading: brandsLoading } = trpc.brands.list.useQuery();
  const { data: decisionMakers, isLoading: dmLoading } = trpc.decisionMakers.list.useQuery();

  const isLoading = statsLoading || eventsLoading || brandsLoading || dmLoading;

  // Preparar dados para gráficos
  const eventsBySegment = events
    ? Object.entries(
        events.reduce((acc: Record<string, number>, event) => {
          acc[event.segment] = (acc[event.segment] || 0) + 1;
          return acc;
        }, {})
      ).map(([segment, count]) => ({ segment, count }))
    : [];

  const brandsBySector = brands
    ? Object.entries(
        brands.reduce((acc: Record<string, number>, brand) => {
          acc[brand.sector] = (acc[brand.sector] || 0) + 1;
          return acc;
        }, {})
      ).map(([sector, count]) => ({ sector, count }))
    : [];

  const sponsorshipDistribution = [
    { name: "Master", value: 5, color: "#ff6400" },
    { name: "Ouro", value: 8, color: "#ffa500" },
    { name: "Prata", value: 6, color: "#c0c0c0" },
    { name: "Bronze", value: 4, color: "#cd7f32" },
  ];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-accent" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-6 bg-card border-border hover:border-accent transition-colors">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Eventos Mapeados</p>
              <p className="text-3xl font-bold text-accent mt-2">{stats?.totalEvents || 0}</p>
            </div>
            <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
              <span className="text-xl">📊</span>
            </div>
          </div>
        </Card>

        <Card className="p-6 bg-card border-border hover:border-accent transition-colors">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Marcas Patrocinadoras</p>
              <p className="text-3xl font-bold text-accent mt-2">{brands?.length || 0}</p>
            </div>
            <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
              <span className="text-xl">🏢</span>
            </div>
          </div>
        </Card>

        <Card className="p-6 bg-card border-border hover:border-accent transition-colors">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Decisores Mapeados</p>
              <p className="text-3xl font-bold text-accent mt-2">{decisionMakers?.length || 0}</p>
            </div>
            <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
              <span className="text-xl">👥</span>
            </div>
          </div>
        </Card>

        <Card className="p-6 bg-card border-border hover:border-accent transition-colors">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground">ROI Médio Estimado</p>
              <p className="text-3xl font-bold text-accent mt-2">{stats?.avgROI.toFixed(1)}%</p>
            </div>
            <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
              <span className="text-xl">📈</span>
            </div>
          </div>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Eventos por Segmento */}
        <Card className="p-6 bg-card border-border">
          <h3 className="text-lg font-semibold text-foreground mb-4">Eventos por Segmento</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={eventsBySegment}>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.20 0.01 280)" />
              <XAxis dataKey="segment" stroke="oklch(0.65 0.01 280)" />
              <YAxis stroke="oklch(0.65 0.01 280)" />
              <Tooltip contentStyle={{ backgroundColor: "oklch(0.12 0.01 280)", border: "1px solid oklch(0.20 0.01 280)" }} />
              <Bar dataKey="count" fill="oklch(0.62 0.25 25)" />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* Marcas por Setor */}
        <Card className="p-6 bg-card border-border">
          <h3 className="text-lg font-semibold text-foreground mb-4">Marcas por Setor</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={brandsBySector}>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.20 0.01 280)" />
              <XAxis dataKey="sector" stroke="oklch(0.65 0.01 280)" angle={-45} textAnchor="end" height={80} />
              <YAxis stroke="oklch(0.65 0.01 280)" />
              <Tooltip contentStyle={{ backgroundColor: "oklch(0.12 0.01 280)", border: "1px solid oklch(0.20 0.01 280)" }} />
              <Bar dataKey="count" fill="oklch(0.55 0.25 15)" />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* Distribuição de Patrocínios */}
        <Card className="p-6 bg-card border-border">
          <h3 className="text-lg font-semibold text-foreground mb-4">Distribuição por Tipo de Patrocínio</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={sponsorshipDistribution}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, value }) => `${name}: ${value}`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {sponsorshipDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ backgroundColor: "oklch(0.12 0.01 280)", border: "1px solid oklch(0.20 0.01 280)" }} />
            </PieChart>
          </ResponsiveContainer>
        </Card>

        {/* ROI por Evento */}
        <Card className="p-6 bg-card border-border">
          <h3 className="text-lg font-semibold text-foreground mb-4">Top 5 Eventos por ROI</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={events?.slice(0, 5).map(e => ({ name: e.name.substring(0, 15), roi: e.estimatedROI })) || []}>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.20 0.01 280)" />
              <XAxis dataKey="name" stroke="oklch(0.65 0.01 280)" />
              <YAxis stroke="oklch(0.65 0.01 280)" />
              <Tooltip contentStyle={{ backgroundColor: "oklch(0.12 0.01 280)", border: "1px solid oklch(0.20 0.01 280)" }} />
              <Line type="monotone" dataKey="roi" stroke="oklch(0.62 0.25 25)" strokeWidth={2} dot={{ fill: "oklch(0.62 0.25 25)" }} />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Resumo Executivo */}
      <Card className="p-6 bg-gradient-to-br from-card to-card/50 border-border">
        <h3 className="text-lg font-semibold text-foreground mb-4">Resumo Executivo</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
          <div>
            <p className="text-muted-foreground">Público Total Estimado</p>
            <p className="text-2xl font-bold text-accent mt-1">
              {events ? (events.reduce((sum, e) => sum + (e.estimatedPublic || 0), 0) / 1000).toFixed(0) : 0}K
            </p>
          </div>
          <div>
            <p className="text-muted-foreground">Alcance de Mídia Total</p>
            <p className="text-2xl font-bold text-accent mt-1">
              {events ? (events.reduce((sum, e) => sum + (e.mediaReach || 0), 0) / 1000000).toFixed(1) : 0}M
            </p>
          </div>
          <div>
            <p className="text-muted-foreground">Taxa de Conversão Média</p>
            <p className="text-2xl font-bold text-accent mt-1">
              {events && events.length > 0
                ? (events.reduce((sum, e) => sum + (e.conversionRate || 0), 0) / events.length).toFixed(1)
                : 0}%
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}
