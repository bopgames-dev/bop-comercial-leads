# Component Patterns - Commercial Intelligence Platform

This reference document provides common patterns for building React components in commercial intelligence platforms.

## Dashboard Component Pattern

```typescript
// client/src/pages/Dashboard.tsx
import { useEffect, useState } from 'react';
import { Card } from '@/components/ui/card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { trpc } from '@/lib/trpc';

/**
 * Dashboard Component
 * 
 * Displays KPIs and charts for executive overview.
 * Features:
 * - 4 KPI cards with metrics
 * - 4 interactive charts
 * - Real-time data updates
 * - Loading and error states
 */
export default function Dashboard() {
  // Fetch stats from backend
  const { data: stats, isLoading } = trpc.stats.useQuery();

  if (isLoading) {
    return <div className="p-8">Loading...</div>;
  }

  return (
    <div className="space-y-8">
      {/* KPI Cards */}
      <div className="grid grid-cols-4 gap-4">
        <KPICard 
          title="Total Items" 
          value={stats?.totalItems || 0}
          icon="📊"
        />
        <KPICard 
          title="Total Users" 
          value={stats?.totalUsers || 0}
          icon="👥"
        />
        <KPICard 
          title="Average Metric" 
          value={stats?.averageMetric?.toFixed(2) || 0}
          icon="📈"
        />
        <KPICard 
          title="Total Value" 
          value={`$${stats?.totalValue || 0}`}
          icon="💰"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-2 gap-4">
        <ChartCard title="Distribution by Type">
          <DistributionChart data={stats?.distribution} />
        </ChartCard>
        <ChartCard title="Trends Over Time">
          <TrendsChart data={stats?.trends} />
        </ChartCard>
        <ChartCard title="Segment Analysis">
          <SegmentChart data={stats?.segments} />
        </ChartCard>
        <ChartCard title="Top Rankings">
          <RankingChart data={stats?.rankings} />
        </ChartCard>
      </div>
    </div>
  );
}

// KPI Card Component
function KPICard({ title, value, icon }) {
  return (
    <Card className="p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground">{title}</p>
          <p className="text-3xl font-bold mt-2">{value}</p>
        </div>
        <div className="text-4xl">{icon}</div>
      </div>
    </Card>
  );
}

// Chart Card Wrapper
function ChartCard({ title, children }) {
  return (
    <Card className="p-6">
      <h3 className="text-lg font-semibold mb-4">{title}</h3>
      {children}
    </Card>
  );
}
```

## List Page with Filters Pattern

```typescript
// client/src/pages/ItemList.tsx
import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { trpc } from '@/lib/trpc';

/**
 * Item List Page
 * 
 * Displays paginated list with filters and search.
 * Features:
 * - Multi-select filters
 * - Full-text search
 * - Pagination
 * - Export buttons
 * - Action links
 */
export default function ItemList() {
  const [search, setSearch] = useState('');
  const [filters, setFilters] = useState({
    type: '',
    segment: '',
    city: '',
  });

  // Fetch items with filters
  const { data: items, isLoading } = trpc.items.list.useQuery({
    search,
    ...filters,
  });

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="space-y-6">
      {/* Filters Section */}
      <div className="bg-card p-6 rounded-lg space-y-4">
        <div className="grid grid-cols-3 gap-4">
          <div>
            <label className="text-sm font-medium">Search</label>
            <Input
              placeholder="Search by name..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div>
            <label className="text-sm font-medium">Type</label>
            <select
              value={filters.type}
              onChange={(e) => handleFilterChange('type', e.target.value)}
              className="w-full px-3 py-2 border rounded-md"
            >
              <option value="">All Types</option>
              <option value="type1">Type 1</option>
              <option value="type2">Type 2</option>
            </select>
          </div>
          <div>
            <label className="text-sm font-medium">Segment</label>
            <select
              value={filters.segment}
              onChange={(e) => handleFilterChange('segment', e.target.value)}
              className="w-full px-3 py-2 border rounded-md"
            >
              <option value="">All Segments</option>
              <option value="segment1">Segment 1</option>
              <option value="segment2">Segment 2</option>
            </select>
          </div>
        </div>
      </div>

      {/* Items Grid */}
      <div className="grid grid-cols-3 gap-4">
        {items?.map(item => (
          <ItemCard key={item.id} item={item} />
        ))}
      </div>

      {/* Export Button */}
      <div className="flex justify-end">
        <ExportButton items={items} />
      </div>
    </div>
  );
}

// Item Card Component
function ItemCard({ item }) {
  return (
    <div className="bg-card p-4 rounded-lg border border-border hover:border-accent transition">
      <h3 className="font-semibold text-lg mb-2">{item.name}</h3>
      <p className="text-sm text-muted-foreground mb-4">{item.description}</p>
      
      <div className="flex gap-2">
        <Button
          variant="outline"
          size="sm"
          onClick={() => window.location.href = `mailto:${item.email}`}
        >
          Email
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => window.open(item.website)}
        >
          Website
        </Button>
      </div>
    </div>
  );
}

// Export Button Component
function ExportButton({ items }) {
  const handleExport = (format) => {
    const data = format === 'json' 
      ? JSON.stringify(items, null, 2)
      : convertToCSV(items);
    
    const blob = new Blob([data], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `export.${format}`;
    a.click();
  };

  return (
    <div className="flex gap-2">
      <Button onClick={() => handleExport('json')}>Export JSON</Button>
      <Button onClick={() => handleExport('csv')}>Export CSV</Button>
    </div>
  );
}

function convertToCSV(items) {
  if (!items || items.length === 0) return '';
  
  const headers = Object.keys(items[0]);
  const rows = items.map(item =>
    headers.map(header => JSON.stringify(item[header])).join(',')
  );
  
  return [headers.join(','), ...rows].join('\n');
}
```

## Filter Component Pattern

```typescript
// client/src/components/Filters.tsx
import { useState } from 'react';
import { Button } from '@/components/ui/button';

/**
 * Reusable Filters Component
 * 
 * Provides multi-select filtering with clear button.
 * Props:
 * - filters: Current filter values
 * - onChange: Callback when filters change
 * - options: Available filter options
 */
export function Filters({ filters, onChange, options }) {
  const handleClear = () => {
    onChange({});
  };

  return (
    <div className="bg-card p-4 rounded-lg space-y-4">
      <div className="grid grid-cols-4 gap-4">
        {options.map(option => (
          <div key={option.key}>
            <label className="text-sm font-medium block mb-2">
              {option.label}
            </label>
            <select
              value={filters[option.key] || ''}
              onChange={(e) => onChange({
                ...filters,
                [option.key]: e.target.value,
              })}
              className="w-full px-3 py-2 border rounded-md"
            >
              <option value="">All</option>
              {option.values.map(val => (
                <option key={val} value={val}>{val}</option>
              ))}
            </select>
          </div>
        ))}
      </div>
      
      <div className="flex justify-end">
        <Button 
          variant="outline"
          onClick={handleClear}
        >
          Clear Filters
        </Button>
      </div>
    </div>
  );
}
```

## Report Component Pattern

```typescript
// client/src/pages/Report.tsx
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { trpc } from '@/lib/trpc';

/**
 * Strategic Report Page
 * 
 * Displays executive summary and strategic insights.
 * Features:
 * - Executive summary
 * - Top leads/opportunities
 * - Segment analysis
 * - Export in multiple formats
 */
export default function Report() {
  const [exportFormat, setExportFormat] = useState('json');
  const { data: report, isLoading } = trpc.report.generate.useQuery();

  const handleExport = async () => {
    // Call export procedure
    const result = await trpc.report.export.query({ format: exportFormat });
    
    // Download file
    const blob = new Blob([result], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `report.${exportFormat}`;
    a.click();
  };

  if (isLoading) return <div>Loading...</div>;

  return (
    <div className="space-y-8">
      {/* Executive Summary */}
      <section>
        <h2 className="text-2xl font-bold mb-4">Executive Summary</h2>
        <div className="bg-card p-6 rounded-lg">
          <p>{report?.summary}</p>
        </div>
      </section>

      {/* Top Leads */}
      <section>
        <h2 className="text-2xl font-bold mb-4">Top 10 Priority Leads</h2>
        <div className="space-y-2">
          {report?.topLeads?.map((lead, idx) => (
            <div key={idx} className="bg-card p-4 rounded-lg flex justify-between">
              <div>
                <p className="font-semibold">{lead.name}</p>
                <p className="text-sm text-muted-foreground">{lead.reason}</p>
              </div>
              <p className="text-lg font-bold text-accent">{lead.score}/100</p>
            </div>
          ))}
        </div>
      </section>

      {/* Segment Analysis */}
      <section>
        <h2 className="text-2xl font-bold mb-4">Segment Analysis</h2>
        <div className="grid grid-cols-2 gap-4">
          {report?.segments?.map((segment, idx) => (
            <div key={idx} className="bg-card p-6 rounded-lg">
              <h3 className="font-semibold mb-2">{segment.name}</h3>
              <p className="text-sm text-muted-foreground">{segment.analysis}</p>
              <p className="mt-4 text-lg font-bold">
                Opportunity: {segment.opportunityScore}/100
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Export Section */}
      <section className="flex gap-4">
        <select
          value={exportFormat}
          onChange={(e) => setExportFormat(e.target.value)}
          className="px-4 py-2 border rounded-md"
        >
          <option value="json">JSON</option>
          <option value="csv">CSV</option>
          <option value="pdf">PDF</option>
        </select>
        <Button onClick={handleExport}>
          Export Report
        </Button>
      </section>
    </div>
  );
}
```

## Backend Query Pattern

```typescript
// server/db.ts
import { eq, like, and, sql } from 'drizzle-orm';
import { getDb } from './db';

/**
 * Query helper functions
 * 
 * These functions encapsulate database queries and are reused
 * across multiple tRPC procedures.
 */

export async function getItemsWithFilters(filters) {
  const db = await getDb();
  
  let query = db.select().from(items);
  
  // Apply filters
  const conditions = [];
  
  if (filters.search) {
    conditions.push(like(items.name, `%${filters.search}%`));
  }
  
  if (filters.type) {
    conditions.push(eq(items.type, filters.type));
  }
  
  if (filters.segment) {
    conditions.push(eq(items.segment, filters.segment));
  }
  
  if (conditions.length > 0) {
    query = query.where(and(...conditions));
  }
  
  return query.limit(100);
}

export async function getItemStats() {
  const db = await getDb();
  
  const result = await db.select({
    totalItems: sql`COUNT(*)`,
    averageMetric: sql`AVG(metric)`,
    totalValue: sql`SUM(value)`,
  }).from(items);
  
  return result[0];
}

export async function getItemsBySegment() {
  const db = await getDb();
  
  return db.select({
    segment: items.segment,
    count: sql`COUNT(*)`,
    avgValue: sql`AVG(value)`,
  })
    .from(items)
    .groupBy(items.segment);
}
```

## tRPC Procedure Pattern

```typescript
// server/routers.ts
import { publicProcedure, router } from './_core/trpc';
import { z } from 'zod';
import { getItemsWithFilters, getItemStats } from './db';

/**
 * tRPC Routers
 * 
 * Define type-safe API procedures that are automatically
 * available on the frontend via trpc hooks.
 */

export const appRouter = router({
  items: router({
    // List items with filtering
    list: publicProcedure
      .input(z.object({
        search: z.string().optional(),
        type: z.string().optional(),
        segment: z.string().optional(),
      }))
      .query(async ({ input }) => {
        return getItemsWithFilters(input);
      }),

    // Get single item
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        return db.select().from(items).where(eq(items.id, input.id));
      }),

    // Get statistics
    stats: publicProcedure
      .query(async () => {
        return getItemStats();
      }),
  }),
});
```

---

**Version**: 1.0.0  
**Last Updated**: May 2026
