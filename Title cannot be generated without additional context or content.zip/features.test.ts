import { describe, expect, it, beforeAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock context for testing
function createMockContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user",
      email: "test@example.com",
      name: "Test User",
      loginMethod: "test",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("BOP Intelligence Platform - Features", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeAll(() => {
    const ctx = createMockContext();
    caller = appRouter.createCaller(ctx);
  });

  describe("Events", () => {
    it("should list all events", async () => {
      const events = await caller.events.list();
      expect(Array.isArray(events)).toBe(true);
      expect(events.length).toBeGreaterThan(0);
    });

    it("should have valid event structure", async () => {
      const events = await caller.events.list();
      const event = events[0];
      expect(event).toHaveProperty("id");
      expect(event).toHaveProperty("name");
      expect(event).toHaveProperty("type");
      expect(event).toHaveProperty("segment");
      expect(event).toHaveProperty("city");
      expect(event).toHaveProperty("estimatedROI");
    });

    it("should calculate event statistics", async () => {
      const stats = await caller.events.stats();
      expect(stats).toHaveProperty("totalEvents");
      expect(stats).toHaveProperty("totalSponsors");
      expect(stats).toHaveProperty("avgROI");
      expect(stats).toHaveProperty("avgPublic");
      expect(stats.totalEvents).toBeGreaterThan(0);
    });

    it("should have events with geographic data", async () => {
      const events = await caller.events.list();
      const eventsWithCoords = events.filter(e => e.latitude && e.longitude);
      expect(eventsWithCoords.length).toBeGreaterThan(0);
    });
  });

  describe("Brands", () => {
    it("should list all brands", async () => {
      const brands = await caller.brands.list();
      expect(Array.isArray(brands)).toBe(true);
      expect(brands.length).toBeGreaterThan(0);
    });

    it("should have valid brand structure", async () => {
      const brands = await caller.brands.list();
      const brand = brands[0];
      expect(brand).toHaveProperty("id");
      expect(brand).toHaveProperty("name");
      expect(brand).toHaveProperty("sector");
      expect(brand).toHaveProperty("positioning");
    });

    it("should have brands with contact information", async () => {
      const brands = await caller.brands.list();
      const brandsWithEmail = brands.filter(b => b.email);
      expect(brandsWithEmail.length).toBeGreaterThan(0);
    });
  });

  describe("Decision Makers", () => {
    it("should list all decision makers", async () => {
      const decisionMakers = await caller.decisionMakers.list();
      expect(Array.isArray(decisionMakers)).toBe(true);
      expect(decisionMakers.length).toBeGreaterThan(0);
    });

    it("should have valid decision maker structure", async () => {
      const decisionMakers = await caller.decisionMakers.list();
      const dm = decisionMakers[0];
      expect(dm).toHaveProperty("id");
      expect(dm).toHaveProperty("fullName");
      expect(dm).toHaveProperty("position");
      expect(dm).toHaveProperty("company");
      expect(dm).toHaveProperty("email");
      expect(dm).toHaveProperty("decisionLevel");
    });

    it("should have decision makers with email contact", async () => {
      const decisionMakers = await caller.decisionMakers.list();
      const dmWithEmail = decisionMakers.filter(dm => dm.email);
      expect(dmWithEmail.length).toBeGreaterThan(0);
    });

    it("should have decision makers with LinkedIn profile", async () => {
      const decisionMakers = await caller.decisionMakers.list();
      const dmWithLinkedIn = decisionMakers.filter(dm => dm.linkedinUrl);
      expect(dmWithLinkedIn.length).toBeGreaterThan(0);
    });

    it("should have decision makers with different decision levels", async () => {
      const decisionMakers = await caller.decisionMakers.list();
      const levels = new Set(decisionMakers.map(dm => dm.decisionLevel));
      expect(levels.size).toBeGreaterThan(1);
    });
  });

  describe("Sponsorships", () => {
    it("should retrieve sponsorships by event", async () => {
      const events = await caller.events.list();
      if (events.length > 0) {
        const sponsorships = await caller.sponsorships.byEvent({
          eventId: events[0].id,
        });
        expect(Array.isArray(sponsorships)).toBe(true);
      }
    });

    it("should retrieve sponsorships by brand", async () => {
      const brands = await caller.brands.list();
      if (brands.length > 0) {
        const sponsorships = await caller.sponsorships.byBrand({
          brandId: brands[0].id,
        });
        expect(Array.isArray(sponsorships)).toBe(true);
      }
    });
  });

  describe("Reports", () => {
    it("should list all reports", async () => {
      const reports = await caller.reports.list();
      expect(Array.isArray(reports)).toBe(true);
    });
  });

  describe("Data Integrity", () => {
    it("should have consistent event data", async () => {
      const events = await caller.events.list();
      events.forEach(event => {
        expect(event.name).toBeTruthy();
        expect(event.type).toBeTruthy();
        expect(event.segment).toBeTruthy();
        expect(event.city).toBeTruthy();
        if (event.estimatedROI) {
          expect(event.estimatedROI).toBeGreaterThanOrEqual(0);
        }
      });
    });

    it("should have consistent brand data", async () => {
      const brands = await caller.brands.list();
      brands.forEach(brand => {
        expect(brand.name).toBeTruthy();
        expect(brand.sector).toBeTruthy();
      });
    });

    it("should have consistent decision maker data", async () => {
      const decisionMakers = await caller.decisionMakers.list();
      decisionMakers.forEach(dm => {
        expect(dm.fullName).toBeTruthy();
        expect(dm.position).toBeTruthy();
        expect(dm.company).toBeTruthy();
        expect(dm.email).toBeTruthy();
      });
    });
  });
});
