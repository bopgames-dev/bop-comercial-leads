import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { BOPDashboardLayout } from "./components/BOPDashboardLayout";
import Dashboard from "./pages/Dashboard";
import Events from "./pages/Events";
import Brands from "./pages/Brands";
import DecisionMakers from "./pages/DecisionMakers";
import MapPage from "./pages/Map";
import Report from "./pages/Report";

function Router() {
  return (
    <BOPDashboardLayout>
      <Switch>
        <Route path={"/"} component={Dashboard} />
        <Route path={"/events"} component={Events} />
        <Route path={"/brands"} component={Brands} />
        <Route path={"/decision-makers"} component={DecisionMakers} />
        <Route path={"/map"} component={MapPage} />
        <Route path={"/report"} component={Report} />
        <Route path={"/404"} component={NotFound} />
        {/* Final fallback route */}
        <Route component={NotFound} />
      </Switch>
    </BOPDashboardLayout>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
