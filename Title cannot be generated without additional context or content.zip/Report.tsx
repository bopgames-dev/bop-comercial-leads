import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, Download, TrendingUp, AlertCircle } from "lucide-react";
import { useState } from "react";

/**
 * Report Page Component
 * Exibe análise estratégica com leads prioritários, oportunidades por segmento
 * e opções de exportação em JSON, CSV e PDF.
 */
export default function Report() {
  // Buscar dados do servidor
  const { data: events, isLoading: eventsLoading } = trpc.events.list.useQuery();
  const { data: brands, isLoading: brandsLoading } = trpc.brands.list.useQuery();
  const { data: decisionMakers, isLoading: dmLoading } = trpc.decisionMakers.list.useQuery();

  // Estado para formato de exportação
  const [exportFormat, setExportFormat] = useState<"json" | "csv" | "pdf">("json");
  const [isExporting, setIsExporting] = useState(false);

  // Verificar se está carregando
  const isLoading = eventsLoading || brandsLoading || dmLoading;

  /**
   * Calcular leads prioritários
   * Filtra decisores com nível de decisão alto e ordena por importância
   */
  const topLeads = decisionMakers
    ?.filter((dm: any) => dm.decisionLevel === "alto")
    .sort((a: any, b: any) => {
      const aScore = a.decisionLevel === "alto" ? 3 : a.decisionLevel === "medio" ? 2 : 1;
      const bScore = b.decisionLevel === "alto" ? 3 : b.decisionLevel === "medio" ? 2 : 1;
      return bScore - aScore;
    })
    .slice(0, 10) || [];

  /**
   * Calcular oportunidades por segmento
   * Agrupa eventos por segmento e calcula ROI médio
   */
  const opportunitiesBySegment = events
    ? Object.values(
        events.reduce((acc: Record<string, any>, event: any) => {
          if (!acc[event.segment]) {
            acc[event.segment] = {
              segment: event.segment,
              count: 0,
              avgROI: 0,
              totalPublic: 0,
              totalReach: 0,
            };
          }
          acc[event.segment].count += 1;
          acc[event.segment].avgROI += event.estimatedROI || 0;
          acc[event.segment].totalPublic += event.estimatedPublic || 0;
          acc[event.segment].totalReach += event.mediaReach || 0;
          return acc;
        }, {})
      )
        .map((segment: any) => ({
          ...segment,
          avgROI: (segment.avgROI / segment.count).toFixed(1),
        }))
        .sort((a: any, b: any) => parseFloat(b.avgROI) - parseFloat(a.avgROI))
    : [];

  /**
   * Função para exportar dados
   * Gera arquivo no formato selecionado (JSON, CSV ou PDF)
   */
  const handleExport = async () => {
    setIsExporting(true);
    try {
      const reportData = {
        generatedAt: new Date().toLocaleString("pt-BR"),
        summary: {
          totalEvents: events?.length || 0,
          totalBrands: brands?.length || 0,
          totalDecisionMakers: decisionMakers?.length || 0,
          avgROI: events && events.length > 0 ? (events.reduce((sum, e) => sum + (e.estimatedROI || 0), 0) / events.length).toFixed(1) : "0",
        },
        topLeads: topLeads.map((dm: any) => ({
          name: dm.name,
          position: dm.position,
          email: dm.email,
          linkedin: dm.linkedin,
          decisionLevel: dm.decisionLevel,
        })),
        eventsBySegment: events ? events.reduce((acc: Record<string, any[]>, event: any) => {
          if (!acc[event.segment]) acc[event.segment] = [];
          acc[event.segment].push(event);
          return acc;
        }, {}) : {},
      };

      if (exportFormat === "json") {
        // Exportar como JSON
        const jsonString = JSON.stringify(reportData, null, 2);
        const blob = new Blob([jsonString], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `relatorio-bop-${new Date().toISOString().split("T")[0]}.json`;
        a.click();
        URL.revokeObjectURL(url);
      } else if (exportFormat === "csv") {
        // Exportar como CSV
        let csv = "BOP GAMES - Relatório Estratégico\n";
        csv += `Gerado em: ${reportData.generatedAt}\n\n`;
        csv += "RESUMO EXECUTIVO\n";
        csv += `Total de Eventos,${reportData.summary.totalEvents}\n`;
        csv += `Total de Marcas,${reportData.summary.totalBrands}\n`;
        csv += `Total de Decisores,${reportData.summary.totalDecisionMakers}\n`;
        csv += `ROI Médio,${reportData.summary.avgROI}%\n\n`;
        csv += "TOP LEADS PRIORITÁRIOS\n";
        csv += "Nome,Cargo,Email,LinkedIn,Nível de Decisão\n";
        reportData.topLeads.forEach((lead: any) => {
          csv += `"${lead.name}","${lead.position}","${lead.email}","${lead.linkedin}","${lead.decisionLevel}"\n`;
        });

        const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `relatorio-bop-${new Date().toISOString().split("T")[0]}.csv`;
        a.click();
        URL.revokeObjectURL(url);
      } else if (exportFormat === "pdf") {
        // Exportar como PDF (texto simples em arquivo)
        let pdfContent = "BOP GAMES - Relatório Estratégico\n";
        pdfContent += `Gerado em: ${reportData.generatedAt}\n`;
        pdfContent += "=".repeat(60) + "\n\n";
        pdfContent += "RESUMO EXECUTIVO\n";
        pdfContent += "-".repeat(60) + "\n";
        pdfContent += `Total de Eventos: ${reportData.summary.totalEvents}\n`;
        pdfContent += `Total de Marcas: ${reportData.summary.totalBrands}\n`;
        pdfContent += `Total de Decisores: ${reportData.summary.totalDecisionMakers}\n`;
        pdfContent += `ROI Médio: ${reportData.summary.avgROI}%\n\n`;
        pdfContent += "TOP 10 LEADS PRIORITÁRIOS\n";
        pdfContent += "-".repeat(60) + "\n";
        reportData.topLeads.forEach((lead: any, idx: number) => {
          pdfContent += `${idx + 1}. ${lead.name}\n`;
          pdfContent += `   Cargo: ${lead.position}\n`;
          pdfContent += `   Email: ${lead.email}\n`;
          pdfContent += `   LinkedIn: ${lead.linkedin}\n`;
          pdfContent += `   Nível: ${lead.decisionLevel}\n\n`;
        });

        const blob = new Blob([pdfContent], { type: "application/pdf" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `relatorio-bop-${new Date().toISOString().split("T")[0]}.pdf`;
        a.click();
        URL.revokeObjectURL(url);
      }
    } catch (error) {
      console.error("Erro ao exportar:", error);
    } finally {
      setIsExporting(false);
    }
  };

  // Mostrar loading
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-accent" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Cabeçalho com botão de exportação */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Relatório Estratégico</h1>
          <p className="text-muted-foreground mt-2">Análise completa de oportunidades e leads prioritários</p>
        </div>
        <div className="flex gap-2 items-end">
          <div>
            <label className="text-sm text-muted-foreground block mb-2">Formato</label>
            <select
              value={exportFormat}
              onChange={(e) => setExportFormat(e.target.value as "json" | "csv" | "pdf")}
              className="px-3 py-2 bg-input border border-border rounded-lg text-foreground"
            >
              <option value="json">JSON</option>
              <option value="csv">CSV</option>
              <option value="pdf">PDF</option>
            </select>
          </div>
          <Button
            onClick={handleExport}
            disabled={isExporting}
            className="gap-2 bg-accent hover:bg-accent/90"
          >
            <Download className="w-4 h-4" />
            {isExporting ? "Exportando..." : "Exportar"}
          </Button>
        </div>
      </div>

      {/* Resumo Executivo */}
      <Card className="p-6 bg-gradient-to-br from-card to-card/50 border-border">
        <h3 className="text-lg font-semibold text-foreground mb-4">Resumo Executivo</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Total de Eventos</p>
            <p className="text-3xl font-bold text-accent">{events?.length || 0}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Total de Marcas</p>
            <p className="text-3xl font-bold text-accent">{brands?.length || 0}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Total de Decisores</p>
            <p className="text-3xl font-bold text-accent">{decisionMakers?.length || 0}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">ROI Médio Estimado</p>
            <p className="text-3xl font-bold text-accent">
              {events && events.length > 0 ? (events.reduce((sum, e) => sum + (e.estimatedROI || 0), 0) / events.length).toFixed(1) : "0"}%
            </p>
          </div>
        </div>
      </Card>

      {/* Top 10 Leads Prioritários */}
      <Card className="p-6 bg-card border-border">
        <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-accent" />
          Top 10 Leads Prioritários
        </h3>
        {topLeads.length > 0 ? (
          <div className="space-y-3">
            {topLeads.map((lead: any, idx: number) => (
              <div key={lead.id} className="p-4 bg-muted/20 rounded-lg border border-border/50 hover:border-accent/50 transition-colors">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="font-semibold text-foreground">{idx + 1}. {lead.name}</p>
                    <p className="text-sm text-muted-foreground">{lead.position}</p>
                    <div className="flex gap-2 mt-2 text-xs">
                      <a href={`mailto:${lead.email}`} className="text-accent hover:underline">
                        {lead.email}
                      </a>
                      {lead.linkedin && (
                        <a href={lead.linkedin} target="_blank" rel="noopener noreferrer" className="text-accent hover:underline">
                          LinkedIn
                        </a>
                      )}
                    </div>
                  </div>
                  <span className="px-3 py-1 bg-accent/20 text-accent text-xs font-bold rounded">
                    {lead.decisionLevel?.toUpperCase() || "MÉDIO"}
                  </span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-4 bg-muted/20 rounded-lg flex items-center gap-2 text-muted-foreground">
            <AlertCircle className="w-4 h-4" />
            Nenhum lead prioritário encontrado
          </div>
        )}
      </Card>

      {/* Oportunidades por Segmento */}
      <Card className="p-6 bg-card border-border">
        <h3 className="text-lg font-semibold text-foreground mb-4">Oportunidades por Segmento</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {opportunitiesBySegment && opportunitiesBySegment.length > 0 ? (
            opportunitiesBySegment.map((opp: any) => (
              <div key={opp.segment} className="p-4 bg-muted/20 rounded-lg border border-border/50">
                <p className="font-semibold text-foreground">{opp.segment}</p>
                <div className="grid grid-cols-2 gap-2 mt-2 text-sm">
                  <div>
                    <p className="text-muted-foreground">Eventos</p>
                    <p className="text-lg font-bold text-accent">{opp.count}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">ROI Médio</p>
                    <p className="text-lg font-bold text-accent">{opp.avgROI}%</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Público Total</p>
                    <p className="text-sm font-bold text-foreground">{opp.totalPublic.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Alcance</p>
                    <p className="text-sm font-bold text-foreground">{opp.totalReach.toLocaleString()}</p>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-2 p-4 bg-muted/20 rounded-lg flex items-center gap-2 text-muted-foreground">
              <AlertCircle className="w-4 h-4" />
              Nenhuma oportunidade encontrada
            </div>
          )}
        </div>
      </Card>

      {/* Recomendações */}
      <Card className="p-6 bg-card border-border">
        <h3 className="text-lg font-semibold text-foreground mb-4">Recomendações Estratégicas</h3>
        <div className="space-y-3 text-sm text-muted-foreground">
          <p>• Priorize contato com os leads listados acima - eles têm alto poder de decisão</p>
          <p>• Segmento Fitness apresenta maior ROI médio - considere aumentar investimento</p>
          <p>• Explore eventos em estados com menor cobertura para expansão</p>
          <p>• Acompanhe regularmente o desempenho dos patrocínios para otimizar ROI</p>
        </div>
      </Card>
    </div>
  );
}
