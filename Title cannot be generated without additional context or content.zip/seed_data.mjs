/**
 * Seed Data Template - Commercial Intelligence Platform
 * 
 * This file provides a template for populating your database with sample data.
 * Customize the data arrays below with your actual data.
 * 
 * Usage:
 *   node seed_data.mjs
 * 
 * This script connects to the database and inserts sample data for testing.
 */

import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

// Sample data - Customize these arrays with your data
const SAMPLE_EVENTS = [
  {
    name: "Event 1",
    type: "Sports",
    segment: "Football",
    city: "Rio de Janeiro",
    state: "RJ",
    latitude: -22.9068,
    longitude: -43.1729,
    estimatedPublic: 50000,
    mediaReach: 2000000,
    conversionRate: 12.5,
    estimatedROI: 350,
  },
  // Add more events here
];

const SAMPLE_BRANDS = [
  {
    name: "Brand 1",
    sector: "Technology",
    website: "https://brand1.com",
    email: "contact@brand1.com",
    phone: "+55 11 1234-5678",
    sponsorshipLevel: "Master",
  },
  // Add more brands here
];

const SAMPLE_CONTACTS = [
  {
    name: "John Doe",
    position: "Marketing Director",
    email: "john@brand1.com",
    phone: "+55 11 9999-8888",
    linkedin: "https://linkedin.com/in/johndoe",
    decisionLevel: "High",
    brandId: 1,
  },
  // Add more contacts here
];

/**
 * Connect to database and insert sample data
 */
async function seedDatabase() {
  try {
    // Create connection
    const connection = await mysql.createConnection({
      host: process.env.DB_HOST || 'localhost',
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME || 'commercial_intelligence',
    });

    console.log('✅ Connected to database');

    // Insert events
    console.log('📝 Inserting events...');
    for (const event of SAMPLE_EVENTS) {
      const query = `
        INSERT INTO events 
        (name, type, segment, city, state, latitude, longitude, estimatedPublic, mediaReach, conversionRate, estimatedROI)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;
      await connection.execute(query, [
        event.name,
        event.type,
        event.segment,
        event.city,
        event.state,
        event.latitude,
        event.longitude,
        event.estimatedPublic,
        event.mediaReach,
        event.conversionRate,
        event.estimatedROI,
      ]);
    }
    console.log(`✅ Inserted ${SAMPLE_EVENTS.length} events`);

    // Insert brands
    console.log('📝 Inserting brands...');
    for (const brand of SAMPLE_BRANDS) {
      const query = `
        INSERT INTO brands 
        (name, sector, website, email, phone, sponsorshipLevel)
        VALUES (?, ?, ?, ?, ?, ?)
      `;
      await connection.execute(query, [
        brand.name,
        brand.sector,
        brand.website,
        brand.email,
        brand.phone,
        brand.sponsorshipLevel,
      ]);
    }
    console.log(`✅ Inserted ${SAMPLE_BRANDS.length} brands`);

    // Insert contacts
    console.log('📝 Inserting contacts...');
    for (const contact of SAMPLE_CONTACTS) {
      const query = `
        INSERT INTO contacts 
        (name, position, email, phone, linkedin, decisionLevel, brandId)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `;
      await connection.execute(query, [
        contact.name,
        contact.position,
        contact.email,
        contact.phone,
        contact.linkedin,
        contact.decisionLevel,
        contact.brandId,
      ]);
    }
    console.log(`✅ Inserted ${SAMPLE_CONTACTS.length} contacts`);

    // Close connection
    await connection.end();
    console.log('\n✅ Database seeding completed successfully!');

  } catch (error) {
    console.error('❌ Error seeding database:', error.message);
    process.exit(1);
  }
}

// Run seeding
seedDatabase();
