import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, events, brands, sponsorships, decisionMakers, reports } from "../drizzle/schema";
import { ENV } from './_core/env';

// Database instance (lazy-loaded)
let _db: ReturnType<typeof drizzle> | null = null;

/**
 * Get database instance
 * Creates a lazy-loaded connection to avoid errors in local tooling
 */
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

/**
 * Upsert user - Create or update user record
 */
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

/**
 * Get user by OpenID
 */
export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * ============ EVENTS ============
 * Functions for querying events
 */

export async function getAllEvents() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(events);
}

/**
 * Get event by ID
 */
export async function getEventById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(events).where(eq(events.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

/**
 * Get aggregated event statistics
 */
export async function getEventStats() {
  const db = await getDb();
  if (!db) return { totalEvents: 0, totalSponsors: 0, avgROI: 0, avgPublic: 0 };
  
  const allEvents = await db.select().from(events);
  const totalSponsors = allEvents.reduce((sum, e) => sum + (e.sponsorCount || 0), 0);
  const avgROI = allEvents.length > 0 
    ? allEvents.reduce((sum, e) => sum + (e.estimatedROI || 0), 0) / allEvents.length 
    : 0;
  const avgPublic = allEvents.length > 0
    ? allEvents.reduce((sum, e) => sum + (e.estimatedPublic || 0), 0) / allEvents.length
    : 0;

  return {
    totalEvents: allEvents.length,
    totalSponsors,
    avgROI: Math.round(avgROI * 100) / 100,
    avgPublic: Math.round(avgPublic),
  };
}

/**
 * ============ BRANDS ============
 * Functions for querying brands
 */

export async function getAllBrands() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(brands);
}

/**
 * Get brand by ID
 */
export async function getBrandById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(brands).where(eq(brands.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

/**
 * ============ SPONSORSHIPS ============
 * Functions for querying sponsorship relationships
 */

// Get sponsorships for an event
export async function getSponsorshipsByEvent(eventId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(sponsorships).where(eq(sponsorships.eventId, eventId));
}

/**
 * Get brands for an event (with sponsorship details)
 */
export async function getBrandsByEvent(eventId: number) {
  const db = await getDb();
  if (!db) return [];
  
  // Get sponsorships for this event
  const sponsorshipsData = await db
    .select()
    .from(sponsorships)
    .where(eq(sponsorships.eventId, eventId));
  
  // Get brand details for each sponsorship
  const brandsData = await Promise.all(
    sponsorshipsData.map(async (sponsorship) => {
      const brand = await getBrandById(sponsorship.brandId);
      return {
        ...brand,
        sponsorshipType: sponsorship.sponsorshipType,
      };
    })
  );
  
  return brandsData.filter(b => b !== undefined);
}

export async function getSponsorshipsByBrand(brandId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(sponsorships).where(eq(sponsorships.brandId, brandId));
}

/**
 * ============ DECISION MAKERS ============
 * Functions for querying decision makers
 */

/**
 * Get all decision makers
 */
export async function getAllDecisionMakers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(decisionMakers);
}

/**
 * Get decision maker by ID
 */
export async function getDecisionMakerById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(decisionMakers).where(eq(decisionMakers.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

/**
 * ============ REPORTS ============
 * Functions for querying reports
 */

/**
 * Get all reports
 */
export async function getAllReports() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(reports);
}

/**
 * Get report by ID
 */
export async function getReportById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(reports).where(eq(reports.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}
