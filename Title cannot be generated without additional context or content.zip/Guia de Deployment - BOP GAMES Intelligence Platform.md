# Guia de Deployment - BOP GAMES Intelligence Platform

## 📦 Arquivos Inclusos

O arquivo `bop-intelligence-platform.zip` contém:
- Código-fonte completo (React + Express + tRPC)
- Banco de dados com schema e dados de exemplo
- Documentação completa
- Testes unitários
- Configuração de produção

## 🚀 Passos para Deployment em Domínio Próprio

### 1. Preparar o Servidor

#### Linux/Ubuntu (Recomendado)
```bash
# Atualizar sistema
sudo apt-get update && sudo apt-get upgrade -y

# Instalar Node.js 22
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt-get install -y nodejs

# Instalar pnpm
npm install -g pnpm

# Instalar Git
sudo apt-get install -y git

# Instalar Nginx (para reverse proxy)
sudo apt-get install -y nginx

# Instalar MySQL Client (se usar banco remoto)
sudo apt-get install -y mysql-client
```

### 2. Extrair e Configurar Projeto

```bash
# Extrair arquivo
unzip bop-intelligence-platform.zip
cd bop-intelligence-platform

# Instalar dependências
pnpm install

# Criar arquivo .env.production
cat > .env.production << 'EOF'
# Banco de Dados (substitua com seus valores)
DATABASE_URL=mysql://usuario:senha@seu-banco.com:3306/bop_games

# Autenticação OAuth (obtenha em seu provedor OAuth)
VITE_APP_ID=seu_app_id_aqui
OAUTH_SERVER_URL=https://api.seu-oauth.com
VITE_OAUTH_PORTAL_URL=https://seu-oauth.com/login

# JWT (gere uma chave segura)
JWT_SECRET=$(openssl rand -base64 32)

# Informações do Proprietário
OWNER_OPEN_ID=seu_open_id
OWNER_NAME=BOP GAMES

# APIs (se usar Manus)
BUILT_IN_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=sua_chave_api
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im
VITE_FRONTEND_FORGE_API_KEY=sua_chave_frontend

# Porta (não altere se usar Nginx)
PORT=3000
EOF
```

### 3. Preparar Banco de Dados

```bash
# Se usar MySQL local
sudo mysql -u root -p << 'EOF'
CREATE DATABASE bop_games CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'bop_user'@'localhost' IDENTIFIED BY 'sua_senha_segura';
GRANT ALL PRIVILEGES ON bop_games.* TO 'bop_user'@'localhost';
FLUSH PRIVILEGES;
EOF

# Se usar banco remoto, execute as migrações
pnpm db:push
```

### 4. Build para Produção

```bash
# Compilar código
pnpm build

# Verificar se build foi bem-sucedido
ls -la dist/
```

### 5. Configurar Nginx como Reverse Proxy

```bash
# Criar arquivo de configuração
sudo cat > /etc/nginx/sites-available/bop-games << 'EOF'
server {
    listen 80;
    server_name seu-dominio.com www.seu-dominio.com;
    
    # Redirecionar HTTP para HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name seu-dominio.com www.seu-dominio.com;

    # Certificados SSL (use Let's Encrypt)
    ssl_certificate /etc/letsencrypt/live/seu-dominio.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/seu-dominio.com/privkey.pem;

    # Configurações SSL
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;

    # Logs
    access_log /var/log/nginx/bop-games-access.log;
    error_log /var/log/nginx/bop-games-error.log;

    # Proxy para Node.js
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
EOF

# Ativar configuração
sudo ln -s /etc/nginx/sites-available/bop-games /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

# Testar configuração
sudo nginx -t

# Reiniciar Nginx
sudo systemctl restart nginx
```

### 6. Instalar Certificado SSL (Let's Encrypt)

```bash
# Instalar Certbot
sudo apt-get install -y certbot python3-certbot-nginx

# Gerar certificado
sudo certbot certonly --nginx -d seu-dominio.com -d www.seu-dominio.com

# Renovação automática
sudo systemctl enable certbot.timer
```

### 7. Criar Serviço Systemd

```bash
# Criar arquivo de serviço
sudo cat > /etc/systemd/system/bop-games.service << 'EOF'
[Unit]
Description=BOP GAMES Intelligence Platform
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/bop-intelligence-platform
Environment="NODE_ENV=production"
ExecStart=/home/ubuntu/.local/share/pnpm/pnpm start
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Ativar serviço
sudo systemctl daemon-reload
sudo systemctl enable bop-games
sudo systemctl start bop-games

# Verificar status
sudo systemctl status bop-games
```

### 8. Monitoramento e Logs

```bash
# Ver logs em tempo real
sudo journalctl -u bop-games -f

# Ver logs do Nginx
sudo tail -f /var/log/nginx/bop-games-error.log
sudo tail -f /var/log/nginx/bop-games-access.log

# Verificar se aplicação está rodando
curl -I https://seu-dominio.com
```

### 9. Backup e Manutenção

```bash
# Backup do banco de dados (diário)
sudo cat > /usr/local/bin/backup-bop-games.sh << 'EOF'
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backups/bop-games"
mkdir -p $BACKUP_DIR
mysqldump -u bop_user -p'sua_senha' bop_games > $BACKUP_DIR/bop_games_$DATE.sql
gzip $BACKUP_DIR/bop_games_$DATE.sql
find $BACKUP_DIR -name "*.sql.gz" -mtime +30 -delete
EOF

sudo chmod +x /usr/local/bin/backup-bop-games.sh

# Agendar backup diário (crontab)
sudo crontab -e
# Adicionar: 0 2 * * * /usr/local/bin/backup-bop-games.sh
```

---

## 🔧 Troubleshooting

### Aplicação não inicia
```bash
# Verificar logs
sudo journalctl -u bop-games -n 50

# Verificar porta 3000
sudo lsof -i :3000

# Verificar variáveis de ambiente
cat .env.production
```

### Erro de conexão com banco de dados
```bash
# Testar conexão
mysql -u bop_user -p -h seu-banco.com -e "USE bop_games; SELECT 1;"

# Verificar DATABASE_URL
echo $DATABASE_URL
```

### Nginx retorna erro 502
```bash
# Verificar se Node.js está rodando
sudo systemctl status bop-games

# Reiniciar serviço
sudo systemctl restart bop-games

# Verificar logs do Nginx
sudo tail -f /var/log/nginx/bop-games-error.log
```

### Certificado SSL expirado
```bash
# Renovar certificado
sudo certbot renew --force-renewal

# Reiniciar Nginx
sudo systemctl restart nginx
```

---

## 📊 Monitoramento de Performance

### Verificar Uso de Recursos
```bash
# CPU e Memória
top -p $(pgrep -f "node dist/index.js")

# Disco
df -h

# Conexões de banco
mysql -u bop_user -p -e "SHOW PROCESSLIST;"
```

### Otimizações Recomendadas
1. Ativar compressão Gzip no Nginx
2. Implementar cache de assets estáticos
3. Usar CDN para imagens e arquivos grandes
4. Monitorar performance com ferramentas como New Relic ou DataDog

---

## 🔐 Segurança

### Checklist de Segurança
- [ ] Alterar senhas padrão
- [ ] Ativar firewall (UFW)
- [ ] Configurar fail2ban para proteção contra brute force
- [ ] Ativar 2FA no banco de dados
- [ ] Usar HTTPS/SSL obrigatório
- [ ] Manter Node.js e dependências atualizadas
- [ ] Fazer backup regular do banco de dados
- [ ] Monitorar logs de erro e acesso

### Comandos Úteis
```bash
# Ativar firewall
sudo ufw enable
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Instalar fail2ban
sudo apt-get install -y fail2ban
sudo systemctl enable fail2ban
```

---

## 📞 Suporte

Para dúvidas ou problemas:
- Email: contato@bopgames.com.br
- Documentação: Veja DOCUMENTACAO.md
- Logs: `/var/log/nginx/` e `journalctl -u bop-games`

---

**Versão**: 1.0.0  
**Data**: 04 de maio de 2026  
**Suporte**: BOP GAMES Team
