import { publicProcedure, router } from "../_core/trpc";
import { z } from "zod";
import { getAllEvents, getAllBrands, getAllDecisionMakers } from "../db";
import { exportToCSV, exportToPDF } from "../export";

export const exportRouter = router({
  report: publicProcedure
    .input(
      z.object({
        format: z.enum(["json", "csv", "pdf"]),
      })
    )
    .mutation(async ({ input }) => {
      // Buscar dados
      const events = await getAllEvents();
      const brands = await getAllBrands();
      const decisionMakers = await getAllDecisionMakers();

      // Calcular top leads
      const topLeads = (decisionMakers as any[])
        .filter((dm: any) => dm.decisionLevel === "alto")
        .sort((a: any, b: any) => {
          const aScore = a.decisionLevel === "alto" ? 3 : a.decisionLevel === "medio" ? 2 : 1;
          const bScore = b.decisionLevel === "alto" ? 3 : b.decisionLevel === "medio" ? 2 : 1;
          return bScore - aScore;
        })
        .slice(0, 10)
        .map((dm: any) => ({
          name: dm.fullName,
          position: dm.position,
          company: dm.company,
          email: dm.email || "",
          linkedin: dm.linkedinUrl || "",
          whatsapp: dm.whatsapp || "",
        }));

      const reportData = {
        generatedAt: new Date().toISOString(),
        summary: {
          totalEvents: events.length,
          totalBrands: brands.length,
          totalDecisionMakers: decisionMakers.length,
          topLeads,
        },
        events: (events as any[]).map((e: any) => ({
          name: e.name,
          type: e.type,
          segment: e.segment,
          city: e.city,
          state: e.state || "",
          estimatedPublic: e.estimatedPublic,
          mediaReach: e.mediaReach,
          conversionRate: e.conversionRate,
          estimatedROI: e.estimatedROI,
        })),
        brands: (brands as any[]).map((b: any) => ({
          name: b.name,
          sector: b.sector,
          positioning: b.positioning,
          website: b.website || "",
          email: b.email || "",
          phone: b.phone || "",
        })),
        decisionMakers: (decisionMakers as any[]).map((dm: any) => ({
          name: dm.fullName,
          position: dm.position,
          company: dm.company,
          email: dm.email || "",
          linkedin: dm.linkedinUrl || "",
          whatsapp: dm.whatsapp || "",
          decisionLevel: dm.decisionLevel || "",
          seniority: dm.seniority || "",
          location: dm.location || "",
        })),
      };

      if (input.format === "json") {
        return {
          format: "json",
          data: JSON.stringify(reportData, null, 2),
          filename: `bop-intelligence-report-${new Date().toISOString().split("T")[0]}.json`,
        };
      } else if (input.format === "csv") {
        const csvBuffer = await exportToCSV(reportData);
        return {
          format: "csv",
          data: csvBuffer.toString("base64"),
          filename: `bop-intelligence-report-${new Date().toISOString().split("T")[0]}.csv`,
        };
      } else if (input.format === "pdf") {
        const pdfBuffer = await exportToPDF(reportData);
        return {
          format: "pdf",
          data: pdfBuffer.toString("base64"),
          filename: `bop-intelligence-report-${new Date().toISOString().split("T")[0]}.pdf`,
        };
      }

      throw new Error("Invalid format");
    }),
});
