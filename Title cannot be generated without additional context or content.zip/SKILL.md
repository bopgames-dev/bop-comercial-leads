---
name: commercial-intelligence-platform
description: Build complete commercial intelligence platforms with database, dashboard, and analytics. Use for creating business intelligence tools, event/sponsorship platforms, market analysis dashboards, and lead management systems with React, Express, and tRPC.
---

# Commercial Intelligence Platform Builder

This skill provides a complete workflow for building commercial intelligence platforms—web applications that combine data management, executive dashboards, and strategic analytics. It automates the process of creating production-ready platforms with authentication, database integration, and multi-page interfaces.

## When to Use This Skill

Use this skill when you need to:

- Build a business intelligence dashboard with real-time metrics
- Create platforms for event/sponsorship management
- Develop market analysis tools with geographic visualization
- Build lead management and decision-maker databases
- Create strategic reporting systems with data export
- Develop industry-specific analytics platforms

This skill is optimized for platforms that require: structured data, multiple views/pages, filtering and search, geographic visualization, and strategic reporting.

## Platform Architecture

All platforms built with this skill follow a consistent architecture:

| Component | Technology | Purpose |
|-----------|-----------|----------|
| **Frontend** | React 19 + TypeScript | Interactive UI with dashboard, tables, maps, reports |
| **Backend** | Express 4 + tRPC 11 | Type-safe API procedures and business logic |
| **Database** | Drizzle ORM + MySQL | Structured data with migrations and queries |
| **Styling** | Tailwind CSS 4 + shadcn/ui | Responsive, accessible components |
| **Charts** | Recharts 2 | Interactive data visualization |
| **Authentication** | OAuth | Secure user authentication |

## Core Workflow

### Phase 1: Define Data Model

Start by identifying the core entities and relationships:

1. **List all entities** (events, brands, users, etc.)
2. **Define fields** for each entity (name, email, type, etc.)
3. **Identify relationships** (many-to-many, one-to-many, etc.)
4. **Plan seed data** (sample records for testing)

### Phase 2: Create Database Schema

1. Create `drizzle/schema.ts` with all tables
2. Run `pnpm drizzle-kit generate` to create migrations
3. Execute `pnpm db:push` to apply migrations
4. Create seed script to populate sample data

### Phase 3: Build Backend APIs

1. Create query helpers in `server/db.ts`
2. Define tRPC procedures in `server/routers.ts`
3. Implement filtering, searching, and aggregation
4. Add data export functionality (JSON, CSV, PDF)

### Phase 4: Design Frontend Pages

1. Create dashboard with KPIs and charts
2. Build list pages with filters and search
3. Add detail pages or modals
4. Implement geographic visualization (if needed)
5. Create strategic reporting page

### Phase 5: Integrate Components

1. Wire pages to tRPC procedures
2. Implement loading and error states
3. Add export functionality
4. Test all filters and searches

### Phase 6: Documentation and Deployment

1. Add code comments explaining logic
2. Create deployment guide
3. Generate quick-start documentation
4. Prepare for production deployment

## Key Features to Implement

### Dashboard
- 4 KPIs (total items, total users, average metric, total value)
- 4 interactive charts (distribution, trends, segments, rankings)
- Summary cards with key metrics
- Real-time data updates

### List Pages
- Paginated or scrollable lists
- Multiple filter options
- Full-text search
- Export buttons
- Action links (email, website, etc.)

### Filtering System
- Multi-select filters
- Search by name/keyword
- Date range filters (if applicable)
- Combine multiple filters

### Geographic Visualization
- Map with pins or markers
- Regional statistics
- Distribution by location
- Hover/click details

### Strategic Reporting
- Executive summary
- Top items/leads
- Segment analysis
- Opportunity identification
- Export in multiple formats (JSON, CSV, PDF)

## Database Schema Template

Every platform needs these core tables:

```sql
-- Users (authentication)
CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  openId VARCHAR(64) UNIQUE NOT NULL,
  name TEXT,
  email VARCHAR(320),
  role ENUM('user', 'admin') DEFAULT 'user',
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Main entities (customize based on domain)
CREATE TABLE entities (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  type VARCHAR(100),
  segment VARCHAR(100),
  city VARCHAR(100),
  latitude DECIMAL(10,8),
  longitude DECIMAL(11,8),
  metric1 INT,
  metric2 DECIMAL(10,2),
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Related entities (customize based on relationships)
CREATE TABLE relationships (
  id INT PRIMARY KEY AUTO_INCREMENT,
  entity1Id INT NOT NULL,
  entity2Id INT NOT NULL,
  type VARCHAR(100),
  startDate DATE,
  endDate DATE,
  FOREIGN KEY (entity1Id) REFERENCES entities(id),
  FOREIGN KEY (entity2Id) REFERENCES entities(id)
);

-- Contacts/Decision makers
CREATE TABLE contacts (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  position VARCHAR(255),
  email VARCHAR(320),
  phone VARCHAR(20),
  linkedin VARCHAR(255),
  level ENUM('alto', 'medio', 'baixo'),
  entityId INT,
  FOREIGN KEY (entityId) REFERENCES entities(id)
);
```

## API Procedures Template

Implement these core procedures in tRPC:

```typescript
// List with filtering
list: publicProcedure
  .input(z.object({
    segment: z.string().optional(),
    city: z.string().optional(),
    search: z.string().optional(),
  }))
  .query(async ({ input }) => {
    // Filter and return entities
  }),

// Get single item
getById: publicProcedure
  .input(z.object({ id: z.number() }))
  .query(async ({ input }) => {
    // Return single entity with details
  }),

// Export data
export: publicProcedure
  .input(z.object({
    format: z.enum(['json', 'csv', 'pdf']),
  }))
  .query(async ({ input }) => {
    // Generate and return export
  }),

// Aggregated statistics
stats: publicProcedure
  .query(async () => {
    // Return KPIs and metrics
  }),
```

## Frontend Component Structure

Organize components consistently:

```
client/src/
├── pages/
│   ├── Dashboard.tsx          # KPIs and charts
│   ├── List.tsx               # Main list with filters
│   ├── Details.tsx            # Detail view
│   ├── Map.tsx                # Geographic visualization
│   └── Report.tsx             # Strategic reporting
├── components/
│   ├── Layout.tsx             # Main layout wrapper
│   ├── Filters.tsx            # Reusable filter component
│   ├── ExportButton.tsx       # Export functionality
│   └── ui/                    # shadcn/ui components
└── lib/
    └── trpc.ts                # tRPC client
```

## Styling and Theme

Use Tailwind CSS with dark theme:

```css
/* Define in index.css */
:root {
  --background: #0a0a0a;
  --foreground: #ffffff;
  --accent: #ff6400;        /* Primary accent */
  --accent-secondary: #ff0000;  /* Secondary accent */
  --card: #1a1a1a;
  --muted: #333333;
}

/* Apply theme */
@layer base {
  body {
    @apply bg-background text-foreground;
  }
}
```

## Testing Strategy

Implement tests for critical paths:

```typescript
// Test data retrieval
test('list returns filtered entities', async () => {
  const result = await caller.entities.list({ segment: 'type1' });
  expect(result).toHaveLength(expectedCount);
});

// Test export
test('export generates valid JSON', async () => {
  const result = await caller.export({ format: 'json' });
  expect(JSON.parse(result)).toBeDefined();
});

// Test aggregations
test('stats calculates correct metrics', async () => {
  const stats = await caller.stats();
  expect(stats.total).toBeGreaterThan(0);
});
```

## Deployment Checklist

Before deploying to production:

- [ ] All environment variables configured
- [ ] Database migrations applied
- [ ] Tests passing (100% coverage for critical paths)
- [ ] Code comments added to complex logic
- [ ] Error handling implemented
- [ ] Loading states added to UI
- [ ] Mobile responsiveness tested
- [ ] SSL/HTTPS configured
- [ ] Backup strategy implemented
- [ ] Monitoring and logging enabled

## Common Customizations

### Add New Entity Type
1. Add table to `drizzle/schema.ts`
2. Create migration with `pnpm drizzle-kit generate`
3. Add query helper in `server/db.ts`
4. Create tRPC procedure in `server/routers.ts`
5. Build UI page in `client/src/pages/`

### Add New Filter
1. Update input schema in tRPC procedure
2. Add WHERE clause to query
3. Add UI control in filter component
4. Test filtering works correctly

### Add New Chart
1. Add data aggregation in tRPC procedure
2. Create chart component with Recharts
3. Wire to dashboard page
4. Add loading state

### Add New Export Format
1. Create export function (CSV, PDF, etc.)
2. Add to export procedure
3. Update UI to show format options
4. Test exported file format

## Performance Optimization

For large datasets:

- Implement pagination (limit 50 items per page)
- Add database indexes on frequently filtered columns
- Cache aggregated statistics (update hourly)
- Compress API responses with gzip
- Use CDN for static assets
- Implement lazy loading for images

## Security Best Practices

- Use environment variables for secrets
- Validate all inputs on backend
- Implement rate limiting on APIs
- Use HTTPS/SSL in production
- Hash sensitive data
- Regular security audits
- Keep dependencies updated

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Database connection fails | Check DATABASE_URL, verify credentials, test connection |
| Filters not working | Verify WHERE clause in query, check input validation |
| Charts not rendering | Check data format, verify Recharts configuration |
| Export fails | Check file permissions, verify data serialization |
| Slow performance | Add database indexes, implement pagination, check query efficiency |

## Next Steps After Building

1. **Customize data** - Replace sample data with real data
2. **Add authentication** - Configure OAuth provider
3. **Deploy to production** - Follow deployment guide
4. **Monitor performance** - Set up logging and alerts
5. **Gather feedback** - Iterate based on user needs
6. **Expand features** - Add new pages, filters, or reports

## Resources

- **Drizzle ORM**: https://orm.drizzle.team/
- **tRPC**: https://trpc.io/
- **Tailwind CSS**: https://tailwindcss.com/
- **shadcn/ui**: https://ui.shadcn.com/
- **Recharts**: https://recharts.org/
- **React**: https://react.dev/

---

**Version**: 1.0.0  
**Last Updated**: May 2026  
**Author**: Manus AI
