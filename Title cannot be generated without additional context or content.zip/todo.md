# BOP GAMES Intelligence Platform - TODO

## Fase 1: Banco de Dados
- [x] Criar schema de eventos (id, nome, tipo, segmento, cidade, coordenadas, público, alcance, taxa conversão, ROI)
- [x] Criar schema de marcas (id, nome, setor, site, email, telefone, tipo patrocínio)
- [x] Criar schema de patrocínios (marca_id, evento_id, tipo_cota, data_inicio, data_fim)
- [x] Criar schema de decisores (id, nome, cargo, email, linkedin, telefone, empresa_id)
- [x] Criar schema de relatórios (id, titulo, conteudo, data_criacao)
- [x] Executar migrações SQL no banco
- [x] Popular banco com 16 eventos, 15 marcas, 10 decisores

## Fase 2: Layout Base
- [x] Configurar tema dark com CSS variables (fundo escuro, texto claro)
- [x] Definir paleta de cores: laranja/vermelho para acentos
- [x] Criar componente DashboardLayout com sidebar
- [x] Implementar navegação lateral com links para todas as páginas
- [x] Adicionar logo/branding do BOP GAMES no header
- [x] Criar componentes de card e métrica para dashboard

## Fase 3: Páginas Principais
- [x] Dashboard: exibir KPIs (eventos, marcas, decisores, ROI médio)
- [x] Página de Eventos: lista com cards, filtros por tipo/cidade
- [x] Página de Marcas: catálogo com filtros por nível de patrocínio
- [x] Página de Decisores: lista de contatos com informações completas
- [x] Página de Mapa: mapa interativo com pins georreferenciados
- [x] Página de Relatório: análise estratégica e ranking de leads

## Fase 4: Funcionalidades Avançadas
- [x] Implementar busca global em eventos e marcas
- [x] Criar filtros avançados (tipo evento, cidade, setor, nível patrocínio)
- [x] Adicionar botões de ação: email, LinkedIn, WhatsApp
- [x] Implementar exportação JSON de todos os dados
- [x] Criar gráficos de análise (patrocinadores por evento, distribuição por tipo)

## Fase 5: Testes e Entrega
- [x] Testar responsividade em mobile/tablet
- [x] Validar todos os links de ação (email, LinkedIn, WhatsApp)
- [x] Verificar exportação JSON
- [x] Testar filtros e busca
- [x] Criar testes unitários (19 testes passando)
- [x] Corrigir erro de links aninhados (<a> dentro de <a>)
- [x] Criar checkpoint final e entregar ao usuário


## Fase 6: Correções e Melhorias
- [ ] Corrigir página de Mapa (exibir pins georreferenciados)
- [ ] Corrigir página de Relatório (resolver erros de renderização)
- [ ] Adicionar downloads CSV e PDF no Relatório
- [ ] Adicionar comentários detalhados em todo o código
- [ ] Criar documentação de instalação e uso
- [ ] Preparar arquivos para download (ZIP com plataforma completa)
