# Inteligência Comercial BOP GAMES - Dados Coletados

## Eventos de Referência (Brasil)
| Evento | Segmento | Localização | Patrocinadores Relevantes |
|---|---|---|---|
| Rio Open | Tênis | Rio de Janeiro | Itaú, Claro, Santander, Fila, Emirates |
| Arnold Sports Festival | Fitness/Wellness | São Paulo | Integralmedica, Max Titanium, Smart Fit, Black Skull |
| Ironman Brasil | Triathlon | Várias (Florianópolis/SP) | Vivo, Santander, Omint, Track&Field |
| TCB (Torneio Crossfit Brasil) | Crossfit | Várias cidades | BS Cross, Skyhill, Gladius, Hopper |
| Monstar Games | Crossfit | Goiânia/DF | Hele Fitness, KMaker, Integralmedica |
| Maratona do Rio | Corrida | Rio de Janeiro | Itaú Uniclass (Master), Cosan, Michelob Ultra |
| Stock Car | Automobilismo | Nacional | Petrobras, Mobil, ArcelorMittal |

## Patrocinadores Ativos (Setor Fitness/Esporte)
- **Integralmedica**: CMO: Marcio Avólio | VP Marketing: Fernando Moura.
- **Max Titanium**: Foco em Nutrição Esportiva e grandes eventos (Arnold, NEEX).
- **Smart Fit**: Maior rede de academias, patrocina grandes feiras e eventos de massa.
- **Black Skull**: Foco em público hardcore, presença forte no Arnold e NEEX.
- **Lambe Lambe**: Patrocinadora oficial BOP Games 2024 (Drinks naturais).
- **Prefeitura de Belo Horizonte**: Apoio institucional recorrente.

## Decisores Mapeados (Exemplos)
- **Marcio Avólio** (CMO, Integralmedica)
- **Fernando Moura** (VP Marketing, Integralmedica)
- **Diretoria de Marketing** (Max Titanium / Grupo Supley)
- **Head de Patrocínios** (Itaú / Santander / Vivo) - Foco em grandes propriedades.

## Insights Estratégicos Iniciais
1. **Setores Quentes**: Bets (Esportes da Sorte, Pixbet), Fintechs/Bancos (Itaú, Santander), Bebidas (Coca-Cola, Amstel, Red Bull), Suplementação (Integralmedica, Max Titanium).
2. **Fit BOP GAMES**: O evento possui +50 modalidades, o que permite segmentar patrocínios por "eixos" (ex: Marca de Lutas patrocinando o eixo Fight).
3. **Tendência**: Marcas de lifestyle (cervejas artesanais, drinks naturais como Lambe Lambe) estão ganhando espaço em festivais híbridos.
