# BOP GAMES Intelligence Platform - Início Rápido

## 📦 O que você recebeu

Você recebeu uma plataforma web completa de inteligência comercial para patrocínios em eventos esportivos. O pacote inclui:

- ✅ Código-fonte completo (React + Express + TypeScript)
- ✅ Banco de dados com 17 eventos, 15 marcas e 10 decisores
- ✅ Dashboard com 4 KPIs e 4 gráficos
- ✅ 6 páginas funcionais (Dashboard, Eventos, Marcas, Decisores, Mapa, Relatório)
- ✅ Exportação de dados em JSON
- ✅ Tema dark com acentos laranja/vermelho
- ✅ Autenticação OAuth integrada
- ✅ Testes unitários (32 testes)
- ✅ Documentação completa

## 🚀 Instalação Rápida (5 minutos)

### 1. Extrair Arquivo
```bash
unzip bop-intelligence-platform.zip
cd bop-intelligence-platform
```

### 2. Instalar Dependências
```bash
npm install -g pnpm  # Se não tiver pnpm
pnpm install
```

### 3. Configurar Banco de Dados
```bash
# Criar arquivo .env.local
cat > .env.local << 'EOF'
DATABASE_URL=mysql://root:senha@localhost:3306/bop_games
VITE_APP_ID=seu_app_id
OAUTH_SERVER_URL=https://api.oauth.com
VITE_OAUTH_PORTAL_URL=https://oauth.com/login
JWT_SECRET=sua_chave_secreta
OWNER_OPEN_ID=seu_open_id
OWNER_NAME=BOP GAMES
BUILT_IN_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=sua_chave
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im
VITE_FRONTEND_FORGE_API_KEY=sua_chave
EOF
```

### 4. Executar Migrações
```bash
pnpm db:push
```

### 5. Iniciar Servidor
```bash
pnpm dev
```

Acesse: `http://localhost:3000`

## 📋 Estrutura de Pastas

```
bop-intelligence-platform/
├── client/              # Frontend React
│   └── src/
│       ├── pages/       # 6 páginas da aplicação
│       ├── components/  # Componentes reutilizáveis
│       └── index.css    # Tema dark (comentado)
├── server/              # Backend Express
│   ├── db.ts            # Queries do banco (comentado)
│   ├── routers.ts       # APIs tRPC (comentado)
│   └── features.test.ts # Testes (comentado)
├── drizzle/             # Banco de dados
│   └── schema.ts        # Tabelas (comentado)
├── DOCUMENTACAO.md      # Documentação completa
└── README_INICIO_RAPIDO.md # Este arquivo
```

## 🎨 Páginas Disponíveis

| Página | URL | Descrição |
|--------|-----|-----------|
| Dashboard | `/` | 4 KPIs + 4 gráficos |
| Eventos | `/events` | 17 eventos com filtros |
| Marcas | `/brands` | 15 marcas patrocinadoras |
| Decisores | `/decision-makers` | 10 contatos executivos |
| Mapa | `/map` | Distribuição geográfica |
| Relatório | `/report` | Análise estratégica |

## 💾 Dados Inclusos

- **17 Eventos**: Esporte, Fitness, Lifestyle em várias cidades
- **15 Marcas**: Tecnologia, Fitness, Energia, Banco, Naturais
- **10 Decisores**: Com emails, LinkedIn e WhatsApp
- **ROI Médio**: 377.1%
- **Público Total**: 600K+ pessoas
- **Alcance de Mídia**: 35M+ pessoas

## 🔍 Código Comentado

Todo o código importante possui comentários em português explicando:
- Cada função e componente
- Lógica de negócio
- Integração com banco de dados
- Fluxos de autenticação

## 📚 Arquivos de Documentação

1. **DOCUMENTACAO.md** - Documentação técnica completa
2. **GUIA_DEPLOYMENT.md** - Passo a passo para deploy em servidor próprio
3. **README_INICIO_RAPIDO.md** - Este arquivo (início rápido)

## 🛠️ Desenvolvimento

### Adicionar Nova Página
1. Criar arquivo em `client/src/pages/NovaPage.tsx`
2. Adicionar rota em `client/src/App.tsx`
3. Adicionar link no sidebar (`client/src/components/BOPDashboardLayout.tsx`)

### Adicionar Nova Tabela
1. Editar `drizzle/schema.ts`
2. Executar `pnpm drizzle-kit generate`
3. Executar `pnpm db:push`
4. Adicionar queries em `server/db.ts`
5. Criar routers em `server/routers.ts`

### Executar Testes
```bash
pnpm test
```

## 🚀 Deploy em Produção

### Opção 1: Manus (Recomendado)
Clique em "Publish" na interface de gerenciamento

### Opção 2: Servidor Próprio
Siga o guia completo em `GUIA_DEPLOYMENT.md`

## 🔧 Troubleshooting

### Porta 3000 já em uso
```bash
lsof -i :3000
kill -9 <PID>
```

### Erro de banco de dados
```bash
# Verificar conexão
mysql -u root -p -e "SELECT 1;"

# Verificar DATABASE_URL
echo $DATABASE_URL
```

### Módulos não encontrados
```bash
rm -rf node_modules pnpm-lock.yaml
pnpm install
```

## 📞 Suporte

- **Email**: contato@bopgames.com.br
- **Website**: https://bopgames.com.br
- **Documentação**: Veja DOCUMENTACAO.md e GUIA_DEPLOYMENT.md

## 📝 Próximos Passos Sugeridos

1. ✅ Instalar e testar localmente
2. ✅ Customizar dados com seus próprios eventos
3. ✅ Configurar autenticação OAuth
4. ✅ Deploy em servidor de produção
5. ✅ Configurar domínio próprio
6. ✅ Implementar backups automáticos

## 🎯 Funcionalidades Principais

### Dashboard
- 4 KPIs em tempo real
- 4 gráficos interativos
- Resumo executivo

### Eventos
- Lista de 17 eventos
- Filtros por segmento e cidade
- Busca por nome
- Links para site e email

### Marcas
- Catálogo de 15 marcas
- Filtros por setor
- Informações de contato
- Nível de patrocínio

### Decisores
- 10 contatos executivos
- Email, LinkedIn, WhatsApp
- Nível de decisão
- Filtros avançados

### Mapa
- Distribuição por estado
- Estatísticas por região
- Lista de eventos por localização

### Relatório
- Análise estratégica
- Top 10 leads prioritários
- Oportunidades por segmento
- Exportação em JSON

## 🎨 Tema e Cores

- **Fundo**: Dark (#0a0a0a)
- **Acentos**: Laranja (#ff6400) e Vermelho (#ff0000)
- **Texto**: Branco/Cinza claro
- **Cards**: Cinza escuro (#1a1a1a)

## 📊 Estatísticas

- **Linhas de Código**: ~5000+
- **Componentes**: 20+
- **Páginas**: 6
- **Testes**: 32
- **Tempo de Build**: ~8 segundos
- **Tamanho do Bundle**: ~1.2MB (gzip: 321KB)

---

**Versão**: 1.0.0  
**Data**: 04 de maio de 2026  
**Desenvolvido com**: React 19, TypeScript, Express 4, tRPC 11  
**Suporte**: BOP GAMES Team
