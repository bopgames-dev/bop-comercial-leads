import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

const connection = await mysql.createConnection(process.env.DATABASE_URL);

// Dados de eventos
const eventsData = [
  {
    name: "Rio Open",
    type: "Tênis",
    segment: "Esporte",
    description: "ATP 500 - Maior torneio de tênis da América Latina",
    city: "Rio de Janeiro",
    state: "RJ",
    latitude: -22.9068,
    longitude: -43.1729,
    estimatedPublic: 45000,
    mediaReach: 2500000,
    conversionRate: 8.5,
    estimatedROI: 350,
    website: "https://www.rioopen.com",
    email: "contato@rioopen.com",
    sponsorCount: 8
  },
  {
    name: "Stock Car Brasil",
    type: "Automobilismo",
    segment: "Esporte",
    description: "Série profissional de automobilismo",
    city: "São Paulo",
    state: "SP",
    latitude: -23.5505,
    longitude: -46.6333,
    estimatedPublic: 120000,
    mediaReach: 5000000,
    conversionRate: 12.3,
    estimatedROI: 420,
    website: "https://www.stockcar.com.br",
    email: "contato@stockcar.com.br",
    phone: "+55 11 3147-5000",
    sponsorCount: 12
  },
  {
    name: "Ironman Brasil",
    type: "Triathlon",
    segment: "Fitness",
    description: "Triathlon de resistência extrema",
    city: "Brasília",
    state: "DF",
    latitude: -15.8267,
    longitude: -47.8822,
    estimatedPublic: 35000,
    mediaReach: 3000000,
    conversionRate: 9.8,
    estimatedROI: 380,
    website: "https://www.ironman.com/im-brazil",
    email: "brasil@ironman.com",
    sponsorCount: 18
  },
  {
    name: "Arnold Sports Festival South America",
    type: "Fitness & Wellness",
    segment: "Fitness",
    description: "Maior evento multiesportivo, fitness e negócios da América Latina",
    city: "São Paulo",
    state: "SP",
    latitude: -23.5505,
    longitude: -46.6333,
    estimatedPublic: 97000,
    mediaReach: 6500000,
    conversionRate: 14.2,
    estimatedROI: 450,
    website: "https://arnold.savagetgroup.com.br",
    email: "contato@arnold.savagetgroup.com.br",
    phone: "+55 11 3254-0454",
    sponsorCount: 20
  },
  {
    name: "TCB - Torneio Crossfit Brasil",
    type: "Crossfit",
    segment: "Fitness",
    description: "Maior campeonato de crossfit do Brasil",
    city: "Várias cidades",
    state: "SP",
    latitude: -23.5505,
    longitude: -46.6333,
    estimatedPublic: 28000,
    mediaReach: 1800000,
    conversionRate: 15.2,
    estimatedROI: 380,
    website: "https://tcboficial.com.br",
    email: "torneio@crossfitbrasil.com.br",
    sponsorCount: 10
  },
  {
    name: "Monstar Games",
    type: "Crossfit",
    segment: "Fitness",
    description: "Campeonato de crossfit com foco em experiência",
    city: "Goiânia",
    state: "GO",
    latitude: -15.7942,
    longitude: -48.8696,
    estimatedPublic: 24000,
    mediaReach: 1550000,
    conversionRate: 13.9,
    estimatedROI: 360,
    website: "https://monstar.com.br",
    email: "contato@monstar.com.br",
    phone: "(62) 3267-6500",
    sponsorCount: 11
  },
  {
    name: "Fitness Brasil Expo",
    type: "Fitness & Negócios",
    segment: "Fitness",
    description: "Maior feira de fitness e negócios da América Latina",
    city: "São Paulo",
    state: "SP",
    latitude: -23.5505,
    longitude: -46.6333,
    estimatedPublic: 40000,
    mediaReach: 2200000,
    conversionRate: 13.5,
    estimatedROI: 410,
    website: "https://www.fitnessbrasil.com.br",
    email: "contato@fitnessbrasil.com.br",
    sponsorCount: 15
  },
  {
    name: "ENAF - Evento Nacional de Atividade Física",
    type: "Fitness & Educação",
    segment: "Fitness",
    description: "Congresso e feira de fitness com 40 anos de tradição",
    city: "Belo Horizonte",
    state: "MG",
    latitude: -19.9191,
    longitude: -43.9386,
    estimatedPublic: 52000,
    mediaReach: 2800000,
    conversionRate: 11,
    estimatedROI: 360,
    website: "https://www.portalenaf.com.br",
    email: "contato@portalenaf.com.br",
    sponsorCount: 12
  },
  {
    name: "Maratona do Rio",
    type: "Corrida",
    segment: "Esporte",
    description: "Maior maratona do Rio de Janeiro",
    city: "Rio de Janeiro",
    state: "RJ",
    latitude: -22.9068,
    longitude: -43.1729,
    estimatedPublic: 25000,
    mediaReach: 1200000,
    conversionRate: 10.2,
    estimatedROI: 320,
    website: "https://www.maratonadorio.com.br",
    email: "contato@maratonadorio.com.br",
    sponsorCount: 10
  },
  {
    name: "BOP GAMES Belo Horizonte",
    type: "Multiesportivo",
    segment: "Lifestyle",
    description: "Maior festival multiesportivo da América Latina",
    city: "Belo Horizonte",
    state: "MG",
    latitude: -19.9191,
    longitude: -43.9386,
    estimatedPublic: 40000,
    mediaReach: 3500000,
    conversionRate: 16.5,
    estimatedROI: 480,
    website: "https://bopgames.com.br",
    email: "contato@bopgames.com.br",
    phone: "+55 31 98292-8106",
    sponsorCount: 15
  },
  {
    name: "Rally dos Sertões",
    type: "Rally Off-Road",
    segment: "Esporte",
    description: "Rally off-road no sertão brasileiro",
    city: "Nordeste",
    state: "BA",
    latitude: -5.7942,
    longitude: -35.2766,
    estimatedPublic: 80000,
    mediaReach: 4200000,
    conversionRate: 10.5,
    estimatedROI: 390,
    website: "https://sertoes.com.br",
    email: "contato@sertoes.com.br",
    sponsorCount: 15
  },
  {
    name: "Copa Sur Crossfit",
    type: "Crossfit",
    segment: "Fitness",
    description: "CrossFit Qualifying Event - Copa Sul-Americana",
    city: "Rio de Janeiro",
    state: "RJ",
    latitude: -22.9068,
    longitude: -43.1729,
    estimatedPublic: 22000,
    mediaReach: 1500000,
    conversionRate: 16,
    estimatedROI: 340,
    website: "https://cfcopasur.com",
    email: "contato@cfcopasur.com",
    sponsorCount: 8
  },
  {
    name: "NEEX",
    type: "Nutrição Esportiva",
    segment: "Fitness",
    description: "Meeting Internacional de Nutrição Esportiva",
    city: "São Paulo",
    state: "SP",
    latitude: -23.5505,
    longitude: -46.6333,
    estimatedPublic: 35000,
    mediaReach: 2000000,
    conversionRate: 11.5,
    estimatedROI: 375,
    website: "https://neex2025.com.br",
    email: "contato@neex2025.com.br",
    sponsorCount: 13
  },
  {
    name: "BTFF - Brasil Trading Fitness Fair",
    type: "Fitness & Negócios",
    segment: "Fitness",
    description: "Feira de negócios e inovação em fitness",
    city: "São Paulo",
    state: "SP",
    latitude: -23.5505,
    longitude: -46.6333,
    estimatedPublic: 32000,
    mediaReach: 1900000,
    conversionRate: 10.8,
    estimatedROI: 355,
    website: "https://www.btff.com.br",
    email: "contato@btff.com.br",
    sponsorCount: 10
  },
  {
    name: "Volta da Pampulha",
    type: "Corrida",
    segment: "Esporte",
    description: "Corrida de 21km em Belo Horizonte",
    city: "Belo Horizonte",
    state: "MG",
    latitude: -19.9191,
    longitude: -43.9386,
    estimatedPublic: 12000,
    mediaReach: 750000,
    conversionRate: 6.5,
    estimatedROI: 260,
    website: "https://www.voltadapampulha.com.br",
    email: "contato@voltadapampulha.com.br",
    sponsorCount: 7
  },
  {
    name: "Powered by Coffee Games",
    type: "Crossfit",
    segment: "Fitness",
    description: "Maior campeonato de crossfit do Brasil",
    city: "Espírito Santo do Pinhal",
    state: "SP",
    latitude: -22.2289,
    longitude: -46.7689,
    estimatedPublic: 25000,
    mediaReach: 1600000,
    conversionRate: 14.8,
    estimatedROI: 370,
    website: "https://www.pwrdbycoffeegames.com",
    email: "contato@pwrdbycoffeegames.com",
    sponsorCount: 12
  }
];

// Dados de marcas
const brandsData = [
  { name: "Integralmedica", sector: "Suplementação Esportiva", positioning: "Premium", website: "https://www.integralmedica.com.br", email: "contato@integralmedica.com.br", phone: "(11) 3254-0454" },
  { name: "Max Titanium", sector: "Suplementação Esportiva", positioning: "Premium", website: "https://www.maxtitanium.com.br", email: "sac@supley.com.br", phone: "(16) 3506-2045" },
  { name: "Smart Fit", sector: "Academia de Fitness", positioning: "Popular", website: "https://www.smartfit.com.br", email: "contato@smartfit.com.br", phone: "4003-0505" },
  { name: "Panatta", sector: "Equipamentos de Fitness", positioning: "Premium", website: "https://www.panattasport.com", email: "service@panattasport.com", phone: "+39 0733 6137208" },
  { name: "Black Skull", sector: "Suplementação Esportiva", positioning: "Premium", website: "https://www.blackskullusa.com.br", email: "contato@blackskullusa.com.br", phone: "+55 11 3254-0454" },
  { name: "Konnen Fitness", sector: "Equipamentos de Fitness", positioning: "Premium", website: "https://www.konnenfitness.com.br", email: "contato@konnenfitness.com.br", phone: "+55 11 3254-0454" },
  { name: "BS Cross", sector: "Crossfit & Fitness", positioning: "Premium", website: "https://www.bscross.com.br", email: "contato@bscross.com.br", phone: "+55 11 3254-0454" },
  { name: "Skyhill Fitness", sector: "Equipamentos Crossfit", positioning: "Premium", website: "https://www.skyhill.com.br", email: "contato@skyhill.com.br", phone: "+55 11 3254-0454" },
  { name: "Petrobras", sector: "Energia", positioning: "Premium", website: "https://www.petrobras.com.br", email: "contato@petrobras.com.br", phone: "+55 21 3224-1000" },
  { name: "Vivo", sector: "Telecomunicações", positioning: "Premium", website: "https://www.vivo.com.br", email: "contato@vivo.com.br", phone: "+55 11 3254-0454" },
  { name: "Claro", sector: "Telecomunicações", positioning: "Premium", website: "https://www.claro.com.br", email: "contato@claro.com.br", phone: "+55 11 3254-0454" },
  { name: "Santander", sector: "Banco", positioning: "Premium", website: "https://www.santander.com.br", email: "contato@santander.com.br", phone: "+55 11 3254-0454" },
  { name: "Hele Fitness", sector: "Equipamentos Fitness", positioning: "Premium", website: "https://www.helefitness.com.br", email: "contato@helefitness.com.br" },
  { name: "KMaker Fitness", sector: "Equipamentos Crossfit", positioning: "Premium", website: "https://www.kmaker.com.br", email: "contato@kmaker.com.br" },
  { name: "Lambe Lambe", sector: "Bebidas Naturais", positioning: "Premium", website: "https://www.lambelambe.com.br", email: "contato@lambelambe.com.br" }
];

// Dados de decisores
const decisionMakersData = [
  { fullName: "Marcio Avólio", position: "Chief Marketing Officer", company: "Integralmedica", email: "mavolio@integralmedica.com.br", linkedinUrl: "https://br.linkedin.com/in/mavolio", decisionLevel: "alto", seniority: "Executive", location: "São Paulo" },
  { fullName: "Fernando Moura", position: "Vice Presidente de Marketing", company: "Integralmedica", email: "fmoura@integralmedica.com.br", linkedinUrl: "https://br.linkedin.com/in/fernando-moura-15542482", decisionLevel: "alto", seniority: "Executive", location: "São Paulo" },
  { fullName: "Carlos Silva", position: "Head de Marketing", company: "Max Titanium", email: "carlos@maxtitanium.com.br", linkedinUrl: "https://br.linkedin.com/in/carlos-silva", decisionLevel: "alto", seniority: "Senior", location: "Ribeirão Preto" },
  { fullName: "Ana Costa", position: "Diretora de Patrocínios", company: "Smart Fit", email: "ana@smartfit.com.br", linkedinUrl: "https://br.linkedin.com/in/ana-costa", decisionLevel: "alto", seniority: "Senior", location: "São Paulo" },
  { fullName: "Roberto Mendes", position: "Gerente de Marketing", company: "Petrobras", email: "roberto@petrobras.com.br", linkedinUrl: "https://br.linkedin.com/in/roberto-mendes", decisionLevel: "medio", seniority: "Senior", location: "Rio de Janeiro" },
  { fullName: "Juliana Oliveira", position: "Coordenadora de Patrocínios", company: "Vivo", email: "juliana@vivo.com.br", linkedinUrl: "https://br.linkedin.com/in/juliana-oliveira", decisionLevel: "medio", seniority: "Pleno", location: "São Paulo" },
  { fullName: "Paulo Gomes", position: "Head de Parcerias", company: "Claro", email: "paulo@claro.com.br", linkedinUrl: "https://br.linkedin.com/in/paulo-gomes", decisionLevel: "alto", seniority: "Senior", location: "São Paulo" },
  { fullName: "Mariana Ferreira", position: "Gerente de Sponsorship", company: "Santander", email: "mariana@santander.com.br", linkedinUrl: "https://br.linkedin.com/in/mariana-ferreira", decisionLevel: "medio", seniority: "Pleno", location: "São Paulo" },
  { fullName: "Lucas Alves", position: "Brand Manager", company: "Black Skull", email: "lucas@blackskullusa.com.br", linkedinUrl: "https://br.linkedin.com/in/lucas-alves", decisionLevel: "medio", seniority: "Pleno", location: "São Paulo" },
  { fullName: "Camila Santos", position: "Diretora de Marketing", company: "Lambe Lambe", email: "camila@lambelambe.com.br", linkedinUrl: "https://br.linkedin.com/in/camila-santos", decisionLevel: "alto", seniority: "Executive", location: "Belo Horizonte" }
];

try {
  // Inserir eventos
  for (const event of eventsData) {
    await connection.execute(
      `INSERT INTO events (name, type, segment, description, city, state, latitude, longitude, estimatedPublic, mediaReach, conversionRate, estimatedROI, website, email, phone, sponsorCount) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [event.name, event.type, event.segment, event.description, event.city, event.state, event.latitude, event.longitude, event.estimatedPublic, event.mediaReach, event.conversionRate, event.estimatedROI, event.website, event.email, event.phone || null, event.sponsorCount]
    );
  }
  console.log(`✓ Inserted ${eventsData.length} events`);

  // Inserir marcas
  for (const brand of brandsData) {
    await connection.execute(
      `INSERT INTO brands (name, sector, positioning, website, email, phone) 
       VALUES (?, ?, ?, ?, ?, ?)`,
      [brand.name, brand.sector, brand.positioning, brand.website, brand.email, brand.phone || null]
    );
  }
  console.log(`✓ Inserted ${brandsData.length} brands`);

  // Inserir decisores
  for (const dm of decisionMakersData) {
    await connection.execute(
      `INSERT INTO decisionMakers (fullName, position, company, email, phone, linkedinUrl, whatsapp, decisionLevel, seniority, location) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [dm.fullName, dm.position, dm.company, dm.email, dm.phone || null, dm.linkedinUrl, dm.whatsapp || null, dm.decisionLevel, dm.seniority, dm.location]
    );
  }
  console.log(`✓ Inserted ${decisionMakersData.length} decision makers`);

  console.log("\n✅ Database seeding completed successfully!");
  process.exit(0);
} catch (error) {
  console.error("❌ Error seeding database:", error);
  process.exit(1);
} finally {
  await connection.end();
}
