import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { 
  getAllEvents, 
  getEventStats, 
  getAllBrands, 
  getAllDecisionMakers,
  getSponsorshipsByEvent,
  getSponsorshipsByBrand,
  getAllReports 
} from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============ EVENTS ============
  events: router({
    list: publicProcedure.query(async () => {
      const allEvents = await getAllEvents();
      return allEvents;
    }),
    stats: publicProcedure.query(async () => {
      return await getEventStats();
    }),
  }),

  // ============ BRANDS ============
  brands: router({
    list: publicProcedure.query(async () => {
      return await getAllBrands();
    }),
  }),

  // ============ SPONSORSHIPS ============
  sponsorships: router({
    byEvent: publicProcedure
      .input((val: unknown) => {
        if (typeof val === 'object' && val !== null && 'eventId' in val) {
          return val as { eventId: number };
        }
        throw new Error('Invalid input');
      })
      .query(async ({ input }) => {
        return await getSponsorshipsByEvent(input.eventId);
      }),
    byBrand: publicProcedure
      .input((val: unknown) => {
        if (typeof val === 'object' && val !== null && 'brandId' in val) {
          return val as { brandId: number };
        }
        throw new Error('Invalid input');
      })
      .query(async ({ input }) => {
        return await getSponsorshipsByBrand(input.brandId);
      }),
  }),

  // ============ DECISION MAKERS ============
  decisionMakers: router({
    list: publicProcedure.query(async () => {
      return await getAllDecisionMakers();
    }),
  }),

  // ============ REPORTS ============
  reports: router({
    list: publicProcedure.query(async () => {
      return await getAllReports();
    }),
  }),
});

export type AppRouter = typeof appRouter;
