import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState, useMemo } from "react";
import { Loader2, Globe, Mail, Phone } from "lucide-react";

const SPONSORSHIP_COLORS: Record<string, string> = {
  master: "bg-yellow-500/10 text-yellow-600 border-yellow-500/20",
  ouro: "bg-orange-500/10 text-orange-600 border-orange-500/20",
  prata: "bg-gray-400/10 text-gray-400 border-gray-400/20",
  bronze: "bg-amber-700/10 text-amber-700 border-amber-700/20",
};

export default function Brands() {
  const { data: brands, isLoading } = trpc.brands.list.useQuery();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedSector, setSelectedSector] = useState<string | null>(null);

  const sectors = useMemo(
    () => Array.from(new Set(brands?.map(b => b.sector) || [])),
    [brands]
  );

  const filteredBrands = useMemo(() => {
    if (!brands) return [];
    return brands.filter(brand => {
      const matchesSearch = brand.name.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesSector = !selectedSector || brand.sector === selectedSector;
      return matchesSearch && matchesSector;
    });
  }, [brands, searchTerm, selectedSector]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-accent" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Marcas Patrocinadoras</h1>
        <p className="text-muted-foreground mt-2">Catálogo completo de marcas que patrocinam eventos</p>
      </div>

      {/* Filtros */}
      <Card className="p-6 bg-card border-border">
        <h3 className="text-lg font-semibold text-foreground mb-4">Filtros</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="text-sm text-muted-foreground block mb-2">Buscar marca</label>
            <Input
              placeholder="Nome da marca..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-input border-border"
            />
          </div>
          <div>
            <label className="text-sm text-muted-foreground block mb-2">Setor</label>
            <select
              value={selectedSector || ""}
              onChange={(e) => setSelectedSector(e.target.value || null)}
              className="w-full px-3 py-2 bg-input border border-border rounded-lg text-foreground"
            >
              <option value="">Todos os setores</option>
              {sectors.map((sector: string) => (
                <option key={sector} value={sector}>{sector}</option>
              ))}
            </select>
          </div>
          <div className="flex items-end">
            <Button
              onClick={() => {
                setSearchTerm("");
                setSelectedSector(null);
              }}
              variant="outline"
              className="w-full"
            >
              Limpar Filtros
            </Button>
          </div>
        </div>
      </Card>

      {/* Grid de Marcas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredBrands.map(brand => (
          <Card key={brand.id} className="p-6 bg-card border-border hover:border-accent transition-colors flex flex-col">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold text-foreground">{brand.name}</h3>
                <p className="text-xs text-accent mt-1 font-medium">{brand.sector}</p>
              </div>
            </div>

            {brand.description && (
              <p className="text-sm text-muted-foreground mb-4 flex-1">{brand.description}</p>
            )}

            {brand.positioning && (
              <div className="mb-4 p-2 bg-muted/20 rounded">
                <p className="text-xs text-muted-foreground">Posicionamento</p>
                <p className="text-sm font-medium text-foreground">{brand.positioning}</p>
              </div>
            )}

            <div className="space-y-2 mb-4">
              {brand.website && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Globe className="w-4 h-4 text-accent" />
                  <a href={brand.website} target="_blank" rel="noopener noreferrer" className="text-accent hover:underline truncate">
                    {brand.website.replace("https://", "")}
                  </a>
                </div>
              )}
              {brand.email && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Mail className="w-4 h-4 text-accent" />
                  <a href={`mailto:${brand.email}`} className="text-accent hover:underline truncate">
                    {brand.email}
                  </a>
                </div>
              )}
              {brand.phone && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Phone className="w-4 h-4 text-accent" />
                  <a href={`tel:${brand.phone}`} className="text-accent hover:underline">
                    {brand.phone}
                  </a>
                </div>
              )}
            </div>

            <div className="flex gap-2 mt-auto">
              {brand.website && (
                <Button
                  onClick={() => window.open(brand.website || "", "_blank")}
                  size="sm"
                  variant="outline"
                  className="flex-1"
                >
                  Visitar
                </Button>
              )}
              {brand.email && (
                <Button
                  onClick={() => window.location.href = `mailto:${brand.email || ""}`}
                  size="sm"
                  variant="outline"
                  className="flex-1"
                >
                  Contato
                </Button>
              )}
            </div>
          </Card>
        ))}
      </div>

      {filteredBrands.length === 0 && (
        <Card className="p-12 bg-card border-border text-center">
          <p className="text-muted-foreground">Nenhuma marca encontrada com os filtros selecionados</p>
        </Card>
      )}
    </div>
  );
}
